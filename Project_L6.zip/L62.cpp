#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <filesystem>

namespace fs = std::filesystem;

std::string readFASTA(const std::string& filename) {
    std::ifstream in(filename);
    if (!in.is_open()) {
        std::cerr << "Error: Could not open FASTA file: " << filename << "\n";
        std::exit(1);
    }
    std::string line, seq;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '>') continue;
        line.erase(std::remove_if(line.begin(), line.end(), ::isspace), line.end());
        seq += line;
    }

    std::transform(seq.begin(), seq.end(), seq.begin(), ::toupper);
    return seq;
}

std::vector<int> digestEcoRI(const std::string& seq) {
    const std::string motif = "GAATTC";
    std::vector<size_t> cutSites;
    size_t pos = 0;
    while ((pos = seq.find(motif, pos)) != std::string::npos) {
        cutSites.push_back(pos + 1); // cut after the 'G'
        pos += 1;
    }

    std::vector<int> frags;
    size_t prev = 0;
    for (size_t cut : cutSites) {
        frags.push_back(static_cast<int>(cut - prev));
        prev = cut;
    }

    frags.push_back(static_cast<int>(seq.size() - prev));

    return frags;
}

void printGel(const std::vector<int>& fragmentLengths) {
    if (fragmentLengths.empty()) {
        std::cout << "(no fragments)\n";
        return;
    }

    int maxLen = *std::max_element(fragmentLengths.begin(), fragmentLengths.end());
    std::vector<int> sorted = fragmentLengths;
    std::sort(sorted.begin(), sorted.end(), std::greater<>());

    std::cout << "\n--- Gel Electrophoresis Simulation ---\n";
    for (int len : sorted) {
        int indent = static_cast<int>((1.0 - double(len) / maxLen) * 30.0);
        std::cout << std::setw(6) << len << " bp | ";
        for (int i = 0; i < indent; ++i) std::cout << ' ';
        std::cout << "█\n";
    }
    std::cout << "--------------------------------------\n";
}

int main() {
    std::vector<std::string> fnaFiles;
    for (const auto& entry : fs::directory_iterator(fs::current_path())) {
        if (!entry.is_regular_file()) continue;
        auto p = entry.path();
        std::string ext = p.extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
        if (ext == ".fna") fnaFiles.push_back(p.filename().string());
    }
    std::sort(fnaFiles.begin(), fnaFiles.end());

    if (fnaFiles.empty()) {
        std::cerr << "No .fna files found in: " << fs::current_path() << "\n";
        std::cerr << "Place your Influenza genomes (.fna) next to the executable or set the working directory.\n";
        return 1;
    }

    std::cout << "Found " << fnaFiles.size() << " FASTA files (.fna) in " << fs::current_path() << "\n";

    for (const auto& fname : fnaFiles) {
        std::string seq = readFASTA(fname);
        auto frags = digestEcoRI(seq);

        int sites = (int)frags.size() - 1;
        if (sites < 0) sites = 0;

        std::cout << "\n=== " << fname << " ===\n";
        std::cout << "Genome length: " << seq.size() << " bp\n";
        std::cout << "EcoRI sites (GAATTC): " << sites << "\n";
        std::cout << "Fragments: " << frags.size() << "\n";
        printGel(frags);
    }

    return 0;
}
