import argparse
import math
import random
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt


START = "<START>"
END = "<END>"
NL = "<NL>"
UNK = "<UNK>"

HERE = Path(__file__).resolve().parent


def read_text(path_str: str) -> str:

    p = Path(path_str)
    if not p.is_absolute():
        p = HERE / p

    if not p.exists():
        raise FileNotFoundError(
            f"Cannot find file: {p}\n"
            f"Make sure {path_str} is in the same folder as {Path(__file__).name}, or pass an absolute path."
        )

    return p.read_text(encoding="utf-8", errors="ignore")


def tokenize_words_keep_lines(text: str) -> List[str]:

    text = text.lower()
    lines = text.splitlines()
    tokens: List[str] = []

    word_re = re.compile(r"[^\W\d_]+", flags=re.UNICODE)

    for line in lines:
        words = word_re.findall(line)
        tokens.extend(words)
        tokens.append(NL)

    while tokens and tokens[-1] == NL:
        tokens.pop()

    return tokens


def with_markers(tokens: List[str]) -> List[str]:
    return [START] + tokens + [END]

def build_vocab(tokens_a: List[str], tokens_b: List[str]) -> List[str]:
    vocab = set(tokens_a) | set(tokens_b)
    vocab |= {START, END, NL, UNK}
    return sorted(vocab)


def map_unk(tokens: List[str], vocab_set: set) -> List[str]:
    return [t if t in vocab_set else UNK for t in tokens]


Counts = Dict[str, Dict[str, int]]
RowTotals = Dict[str, int]


def build_counts(tokens: List[str]) -> Tuple[Counts, RowTotals]:
    counts: Counts = defaultdict(lambda: defaultdict(int))
    totals: RowTotals = defaultdict(int)

    for prev, nxt in zip(tokens, tokens[1:]):
        counts[prev][nxt] += 1
        totals[prev] += 1

    return counts, totals


def prob_next(prev: str, nxt: str, counts: Counts, totals: RowTotals, vocab: List[str], alpha: float) -> float:

    v = len(vocab)
    c = counts.get(prev, {}).get(nxt, 0)
    t = totals.get(prev, 0)
    return (c + alpha) / (t + alpha * v)


def llr_beta(prev: str, nxt: str,
             counts_pos: Counts, totals_pos: RowTotals,
             counts_neg: Counts, totals_neg: RowTotals,
             vocab: List[str], alpha: float) -> float:

    p_pos = prob_next(prev, nxt, counts_pos, totals_pos, vocab, alpha)
    p_neg = prob_next(prev, nxt, counts_neg, totals_neg, vocab, alpha)
    return math.log(p_pos / p_neg, 2)


def sliding_window_scores(tokens: List[str],
                          counts_pos: Counts, totals_pos: RowTotals,
                          counts_neg: Counts, totals_neg: RowTotals,
                          vocab: List[str], alpha: float,
                          window_words: int) -> Tuple[List[float], List[Tuple[int, int]]]:

    if window_words < 2:
        raise ValueError("window_words must be >= 2 (needs at least 1 transition).")

    scores: List[float] = []
    spans: List[Tuple[int, int]] = []

    n = len(tokens)
    if n < window_words:
        return scores, spans

    for start in range(0, n - window_words + 1):
        end = start + window_words
        s = 0.0
        for prev, nxt in zip(tokens[start:end], tokens[start+1:end]):
            s += llr_beta(prev, nxt, counts_pos, totals_pos, counts_neg, totals_neg, vocab, alpha)
        scores.append(s)
        spans.append((start, end))

    return scores, spans


def plot_scores(scores: List[float], title: str, out_path: str | None = None):
    x = list(range(len(scores)))
    plt.figure()
    plt.plot(x, scores, marker="o")
    plt.axhline(0.0)
    plt.title(title)
    plt.xlabel("Window index")
    plt.ylabel("Sliding-window LLR score (positive=Eminescu, negative=Stănescu)")
    plt.tight_layout()

    if out_path:
        plt.savefig(out_path, dpi=200)
        plt.close()
        print(f"Saved plot to {out_path}")
    else:
        plt.show()

def top_transitions(counts: Counts, totals: RowTotals, vocab: List[str], alpha: float, k: int = 12):
    pairs = []
    for prev in totals.keys():
        for nxt in vocab:
            p = prob_next(prev, nxt, counts, totals, vocab, alpha)
            pairs.append((p, prev, nxt))
    pairs.sort(reverse=True, key=lambda x: x[0])
    return pairs[:k]


def tokens_to_pretty_text(tokens: List[str]) -> str:
    lines = []
    current = []
    for t in tokens:
        if t == NL:
            if current:
                lines.append(" ".join(current))
                current = []
            else:
                lines.append("")
        else:
            current.append(t)
    if current:
        lines.append(" ".join(current))
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Word-level Markov LLR scan: Eminescu vs Stănescu")

    # Defaults match your filenames in the project root (same folder as this script)
    parser.add_argument("--em", type=str, default="Eminescu.txt", help="Eminescu poem .txt (default: Eminescu.txt)")
    parser.add_argument("--ns", type=str, default="Stanescu.txt", help="Stănescu poem .txt (default: Stanescu.txt)")
    parser.add_argument("--test", type=str, default="Hybrid.txt", help="3rd text .txt (default: Hybrid.txt)")

    parser.add_argument("--alpha", type=float, default=1.0, help="Laplace smoothing alpha (default=1.0)")
    parser.add_argument("--window", type=int, default=14, help="Sliding window size in tokens/words (default=14)")
    parser.add_argument("--save_plot", action="store_true", help="Save plot to scores.png instead of showing it")

    args = parser.parse_args()

    em_text = read_text(args.em)
    ns_text = read_text(args.ns)
    test_text = read_text(args.test)

    em_tokens = with_markers(tokenize_words_keep_lines(em_text))
    ns_tokens = with_markers(tokenize_words_keep_lines(ns_text))

    vocab = build_vocab(em_tokens, ns_tokens)
    vocab_set = set(vocab)

    em_tokens = map_unk(em_tokens, vocab_set)
    ns_tokens = map_unk(ns_tokens, vocab_set)

    em_counts, em_totals = build_counts(em_tokens)
    ns_counts, ns_totals = build_counts(ns_tokens)

    alpha = args.alpha

    print("\nTraining summary:")
    print(f"Vocab size (unique tokens incl {START},{END},{NL},{UNK}): {len(vocab)}")
    print(f"Eminescu transitions: {sum(em_totals.values())}")
    print(f"Stănescu transitions: {sum(ns_totals.values())}")

    print("\nTop transitions (Eminescu, by probability):")
    for p, prev, nxt in top_transitions(em_counts, em_totals, vocab, alpha, k=12):
        print(f"  P({nxt} | {prev}) = {p:.4f}")

    print("\nTop transitions (Stănescu, by probability):")
    for p, prev, nxt in top_transitions(ns_counts, ns_totals, vocab, alpha, k=12):
        print(f"  P({nxt} | {prev}) = {p:.4f}")

    test_tokens = tokenize_words_keep_lines(test_text)
    test_tokens = map_unk(test_tokens, vocab_set)

    scan_tokens = test_tokens[:]  # includes NL; excludes START/END
    window = args.window

    scores, spans = sliding_window_scores(
        scan_tokens,
        em_counts, em_totals,
        ns_counts, ns_totals,
        vocab, alpha,
        window_words=window
    )

    print("\nSliding window scan:")
    print(f"Test file: {args.test}")
    print(f"Window size: {window} tokens")
    if not scores:
        print("Test text too short for the chosen window.")
        return

    pos = sum(1 for s in scores if s > 0)
    neg = sum(1 for s in scores if s < 0)
    zer = len(scores) - pos - neg
    print(f"Windows: {len(scores)} | positive(Eminescu): {pos} | negative(Stănescu): {neg} | zero: {zer}")

    max_i = max(range(len(scores)), key=lambda i: scores[i])
    min_i = min(range(len(scores)), key=lambda i: scores[i])

    def window_snippet(i: int) -> str:
        a, b = spans[i]
        snippet_tokens = scan_tokens[a:b]
        return tokens_to_pretty_text(snippet_tokens)

    print(f"\nMost Eminescu-like window score: {scores[max_i]:.4f} (index {max_i})")
    print(window_snippet(max_i))

    print(f"\nMost Stănescu-like window score: {scores[min_i]:.4f} (index {min_i})")
    print(window_snippet(min_i))

    # 6) Plot
    title = "Sliding-window LLR scan (positive=Eminescu, negative=Stănescu)"
    if args.save_plot:
        plot_scores(scores, title, out_path=str(HERE / "scores.png"))
        print("Plot saved as scores.png (good for Moodle screenshot).")
    else:
        plot_scores(scores, title, out_path=None)

    print("\nDone.")


if __name__ == "__main__":
    random.seed(42)
    main()