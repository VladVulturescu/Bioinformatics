import math
import matplotlib.pyplot as plt

ALPH = "ACGT"
IDX = {c: i for i, c in enumerate(ALPH)}

def transition_counts(seq: str):
    counts = [[0 for _ in range(4)] for _ in range(4)]
    for a, b in zip(seq, seq[1:]):
        counts[IDX[a]][IDX[b]] += 1
    return counts

def row_normalize(counts):
    probs = [[0.0 for _ in range(4)] for _ in range(4)]
    for i in range(4):
        s = sum(counts[i])
        if s == 0:
            continue
        for j in range(4):
            probs[i][j] = counts[i][j] / s
    return probs

def beta_matrix(p_plus, p_minus):
    beta = [[0.0 for _ in range(4)] for _ in range(4)]
    for i in range(4):
        for j in range(4):
            a = p_plus[i][j]
            b = p_minus[i][j]

            if a > 0.0 and b > 0.0:
                beta[i][j] = math.log(a / b, 2)
            else:
                beta[i][j] = 0.0
    return beta

def score_sequence(seq, beta):
    total = 0.0
    steps = []
    for a, b in zip(seq, seq[1:]):
        val = beta[IDX[a]][IDX[b]]
        steps.append((a + b, val))
        total += val
    return total, steps

def print_matrix(mat, title, digits=3):
    print(f"\n{title}")
    print("    " + "  ".join(ALPH))
    for i, row in enumerate(mat):
        fmt_row = []
        for x in row:
            fmt_row.append(f"{x:.{digits}f}")
        print(f"{ALPH[i]} | " + "  ".join(fmt_row))

def plot_cumulative_score(seq, beta, title="Cumulative CpG score (log-likelihood ratio)"):
    cum = [0.0]
    labels = ["start"]

    total = 0.0
    for i, (a, b) in enumerate(zip(seq, seq[1:]), start=1):
        val = beta[IDX[a]][IDX[b]]
        total += val
        cum.append(total)
        labels.append(f"{i}:{a}{b}")

    x = list(range(len(cum)))

    plt.figure()
    plt.plot(x, cum, marker="o")
    plt.axhline(0.0)
    plt.title(title)
    plt.xlabel("Step (transition index)")
    plt.ylabel("Cumulative score")
    plt.xticks(x, labels, rotation=60, ha="right")
    plt.tight_layout()
    plt.show()

def main():
    S1 = "ATCGATTCGATATCATACACGTAT"
    S2 = "CTCGACTAGTATGAAGTCCACGCTTG"
    S  = "CAGGTTGGAAACGTAA"

    c1 = transition_counts(S1)
    c2 = transition_counts(S2)

    p_plus  = row_normalize(c1)
    p_minus = row_normalize(c2)

    beta = beta_matrix(p_plus, p_minus)

    print_matrix(p_plus,  "Transition probabilities P(+)")
    print_matrix(p_minus, "Transition probabilities P(-)")
    print_matrix(beta,    "Log-likelihood ratio matrix β = log2(P(+)/P(-))")

    score, steps = score_sequence(S, beta)

    print("\nScoring sequence:", S)
    print("Pairs and β contributions:")
    for pair, val in steps:
        print(f"  {pair}: {val:.3f}")

    print(f"\nTotal score = {score:.4f}")

    if score > 0:
        decision = "CpG island (+)"
    elif score < 0:
        decision = "Non-island (-)"
    else:
        decision = "Tie (score = 0)"

    print("Decision:", decision)

    plot_cumulative_score(S, beta, title=f"Cumulative score for S (final={score:.4f})")

if __name__ == "__main__":
    main()