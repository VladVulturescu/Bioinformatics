#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <stdexcept>

#include <pybind11/embed.h>
#include <pybind11/stl.h>

namespace py = pybind11;
using namespace std;

static string trim(const string& s) {
    size_t a = 0, b = s.size();
    while (a < b && isspace(static_cast<unsigned char>(s[a]))) a++;
    while (b > a && isspace(static_cast<unsigned char>(s[b - 1]))) b--;
    return s.substr(a, b - a);
}

static string loadSequence(const string& path) {
    ifstream in(path);
    if (!in) throw runtime_error("Cannot open file: " + path);

    string line, seq;
    while (getline(in, line)) {
        line = trim(line);
        if (line.empty()) continue;
        if (!line.empty() && line[0] == '>') continue; // FASTA header

        for (char c : line) {
            if (isalpha(static_cast<unsigned char>(c))) {
                char u = static_cast<char>(toupper(static_cast<unsigned char>(c)));
                if (u == 'A' || u == 'C' || u == 'G' || u == 'T') seq.push_back(u);
            }
        }
    }

    if (seq.empty()) throw runtime_error("No valid DNA symbols found in file.");
    return seq;
}

static int baseIndex(char b) {
    switch (b) {
        case 'A': return 0;
        case 'C': return 1;
        case 'G': return 2;
        case 'T': return 3;
        default:  return -1;
    }
}


static double cgPercentFromCounts(const int cnt[4], int win) {
    if (win <= 0) return 0.0;
    double gc = static_cast<double>(cnt[1] + cnt[2]); // C + G
    return 100.0 * gc / static_cast<double>(win);
}


static double kappaICFromCounts(const int cnt[4], int win) {
    if (win < 2) return 0.0;
    double N = static_cast<double>(win);
    double num =
        static_cast<double>(cnt[0]) * (cnt[0] - 1) +
        static_cast<double>(cnt[1]) * (cnt[1] - 1) +
        static_cast<double>(cnt[2]) * (cnt[2] - 1) +
        static_cast<double>(cnt[3]) * (cnt[3] - 1);
    double den = N * (N - 1.0);
    return 100.0 * num / den;
}

static void slidingPatterns(
    const string& seq,
    int win,
    vector<double>& cgVals,
    vector<double>& icVals
) {
    cgVals.clear();
    icVals.clear();

    int n = static_cast<int>(seq.size());
    if (win <= 0 || n < win) return;

    int cnt[4] = {0, 0, 0, 0};


    for (int i = 0; i < win; ++i) {
        int idx = baseIndex(seq[i]);
        if (idx >= 0) cnt[idx]++;
    }

    int windows = n - win + 1;
    cgVals.reserve(windows);
    icVals.reserve(windows);

    for (int start = 0; start < windows; ++start) {
        cgVals.push_back(cgPercentFromCounts(cnt, win));
        icVals.push_back(kappaICFromCounts(cnt, win));

        if (start + win < n) {
            int outIdx = baseIndex(seq[start]);
            int inIdx  = baseIndex(seq[start + win]);
            if (outIdx >= 0) cnt[outIdx]--;
            if (inIdx  >= 0) cnt[inIdx]++;
        }
    }
}

static double meanOf(const vector<double>& v) {
    if (v.empty()) return 0.0;
    double s = 0.0;
    for (double x : v) s += x;
    return s / static_cast<double>(v.size());
}

int main(int argc, char** argv) {
    try {
        if (argc < 2) {
            cout << "Usage: ./dna_pattern sequence.txt [window_size]\n";
            cout << "Default window size = 30 if not specified.\n";
        }

        const string path = (argc >= 2) ? string(argv[1]) : "sequence.txt";
        int win = 30;
        if (argc >= 3) win = stoi(argv[2]);

        string seq = loadSequence(path);
        cout << "Loaded sequence of length " << seq.size() << " bp\n";
        cout << "Sliding window length = " << win << "\n\n";

        vector<double> cgVals, icVals;
        slidingPatterns(seq, win, cgVals, icVals);

        if (cgVals.empty()) {
            cerr << "Sequence is too short for the chosen window size.\n";
            return 1;
        }

        double avgCG = meanOf(cgVals);
        double avgIC = meanOf(icVals);

        cout << "Number of windows: " << cgVals.size() << "\n";
        cout << "Average C+G% = " << avgCG << " (lab expects ~29.27 for the given test)\n";
        cout << "Average IC   = " << avgIC << " (lab expects ~27.53 for the given test)\n\n";

        py::scoped_interpreter guard{};

        const char* pycode = R"PY(
import matplotlib.pyplot as plt

def plot_distribution(cg_vals, ic_vals, avg_cg, avg_ic, out_file="pattern.png"):
    # PromKappa-ish: distribution scatter (IC vs C+G%)
    plt.figure(figsize=(6, 6), dpi=170)

    # marker "_" looks like PromKappa’s little horizontal ticks
    plt.scatter(cg_vals, ic_vals, marker="_", s=50)

    # crosshair like PromKappa
    plt.axvline(50, linestyle="--")
    plt.axhline(50, linestyle="--")

    # mark the mean point (useful for your report too)
    plt.scatter([avg_cg], [avg_ic], s=45)
    plt.text(avg_cg, avg_ic, " mean", fontsize=9, ha="left", va="center")

    plt.xlabel("C+G%")
    plt.ylabel("Kappa IC")
    plt.title("Kappa IC vs C+G% (sliding windows)")
    plt.xlim(0, 100)
    plt.ylim(0, 100)
    plt.tight_layout()
    plt.savefig(out_file)
    plt.close()
)PY";

        py::exec(pycode);

        py::list cgList, icList;
        for (double v : cgVals) cgList.append(v);
        for (double v : icVals) icList.append(v);

        py::module mainMod = py::module::import("__main__");
        mainMod.attr("plot_distribution")(cgList, icList, avgCG, avgIC, "pattern.png");

        cout << "Saved PromKappa-style plot as pattern.png\n";

    } catch (const exception& ex) {
        cerr << "Error: " << ex.what() << "\n";
        return 1;
    }
    return 0;
}
