#include <iostream>
#include <string>
#include <unordered_map>

using namespace std;

string toRNA(const string& s) {
    string out;
    out.reserve(s.size());
    for (unsigned char ch : s) {
        char u = static_cast<char>(std::toupper(ch));
        if (u=='A' || u=='C' || u=='G' || u=='U' || u=='T') {
            if (u=='T') u='U';
            out.push_back(u);
        }
    }
    return out;
}

//'*' = Stop
const unordered_map<string,char> CODON = {{"UUU",'F'},{"UUC",'F'},{"UUA",'L'},{"UUG",'L'},{"CUU",'L'},{"CUC",'L'},{"CUA",'L'},{"CUG",'L'},{"AUU",'I'},{"AUC",'I'},{"AUA",'I'},{"AUG",'M'},{"GUU",'V'},{"GUC",'V'},{"GUA",'V'},{"GUG",'V'},{"UCU",'S'},{"UCC",'S'},{"UCA",'S'},{"UCG",'S'},{"CCU",'P'},{"CCC",'P'},{"CCA",'P'},{"CCG",'P'},
                                        {"ACU",'T'},{"ACC",'T'},{"ACA",'T'},{"ACG",'T'},{"GCU",'A'},{"GCC",'A'},{"GCA",'A'},{"GCG",'A'},{"UAU",'Y'},{"UAC",'Y'},{"UAA",'*'},{"UAG",'*'},
                                        {"CAU",'H'},{"CAC",'H'},{"CAA",'Q'},{"CAG",'Q'},{"AAU",'N'},{"AAC",'N'},{"AAA",'K'},{"AAG",'K'},{"GAU",'D'},{"GAC",'D'},{"GAA",'E'},{"GAG",'E'},{"UGU",'C'},{"UGC",'C'},{"UGA",'*'},{"UGG",'W'},
                                        {"CGU",'R'},{"CGC",'R'},{"CGA",'R'},{"CGG",'R'},{"AGU",'S'},{"AGC",'S'},{"AGA",'R'},
                                        {"AGG",'R'},{"GGU",'G'},{"GGC",'G'},{"GGA",'G'},{"GGG",'G'}};


string translate(const string& rna, bool findStart = true) {
    size_t i = 0;

    if (findStart) {
        i = rna.find("AUG");

        if (i == string::npos) return ""; // no start codon
    }

    string protein;

    for (; i + 2 < rna.size(); i += 3) {
        string codon = rna.substr(i, 3);
        auto it = CODON.find(codon);

        if (it == CODON.end()) break;     // invalid/partial codon

        char aa = it->second;

        if (aa == '*') break;             // stop

        protein.push_back(aa);
    }
    return protein;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cout << "Enter code sequence: \n> ";
    string raw, line;

    while (getline(cin, line)) {
        if (line.empty()) break;
        raw += line;
        raw.push_back('\n');
    }

    string rna = toRNA(raw);
    if (rna.empty()) {
        cerr << "No valid nucleotide letters\n";
        return 1;
    }

    string protein = translate(rna, /*findStart=*/true);

    if (protein.empty() && rna.rfind("AUG", 0) == 0) {
        protein = translate(rna, /*findStart=*/false);
    }

    cout << "RNA: " << rna << "\n";
    cout << "Protein: " << (protein.empty() ? string("[none]") : protein) << "\n";

    return 0;
}
