#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <tuple>
#include <iomanip>

using namespace std;

static const unordered_map<string,char> CODON = {
    {"UUU",'F'},{"UUC",'F'},{"UUA",'L'},{"UUG",'L'},{"CUU",'L'},{"CUC",'L'},{"CUA",'L'},{"CUG",'L'},{"AUU",'I'},{"AUC",'I'},{"AUA",'I'},{"AUG",'M'},{"GUU",'V'},{"GUC",'V'},{"GUA",'V'},{"GUG",'V'},
    {"UCU",'S'},{"UCC",'S'},{"UCA",'S'},{"UCG",'S'},{"CCU",'P'},{"CCC",'P'},{"CCA",'P'},{"CCG",'P'},{"ACU",'T'},{"ACC",'T'},{"ACA",'T'},{"ACG",'T'},{"GCU",'A'},{"GCC",'A'},{"GCA",'A'},{"GCG",'A'},
    {"UAU",'Y'},{"UAC",'Y'},{"UAA",'*'},{"UAG",'*'},{"CAU",'H'},{"CAC",'H'},{"CAA",'Q'},{"CAG",'Q'},
    {"AAU",'N'},{"AAC",'N'},{"AAA",'K'},{"AAG",'K'},{"GAU",'D'},{"GAC",'D'},{"GAA",'E'},{"GAG",'E'},{"UGU",'C'},{"UGC",'C'},{"UGA",'*'},{"UGG",'W'},{"CGU",'R'},{"CGC",'R'},{"CGA",'R'},{"CGG",'R'},{"AGU",'S'},{"AGC",'S'},{"AGA",'R'},{"AGG",'R'},{"GGU",'G'},{"GGC",'G'},{"GGA",'G'},{"GGG",'G'}
};

static const unordered_map<char, string> AA3 = {
    {'A',"Ala"},{'R',"Arg"},{'N',"Asn"},{'D',"Asp"},{'C',"Cys"},{'Q',"Gln"},{'E',"Glu"},{'G',"Gly"},{'H',"His"},{'I',"Ile"},
    {'L',"Leu"},{'K',"Lys"},{'M',"Met"},{'F',"Phe"},{'P',"Pro"},{'S',"Ser"},{'T',"Thr"},{'W',"Trp"},{'Y',"Tyr"},{'V',"Val"},
    {'*',"Stop"}
};

string read_fasta_rna(const string& path) {
    ifstream in(path);
    if (!in) throw runtime_error("Cannot open file: " + path);

    string seq, line;
    seq.reserve(100000);
    while (getline(in, line)) {
        if (!line.empty() && line[0] == '>') continue;
        for (unsigned char ch : line) {
            char u = static_cast<char>(toupper(ch));
            if (u=='A' || u=='C' || u=='G' || u=='T' || u=='U') {
                if (u=='T') u='U';
                seq.push_back(u);
            }
        }
    }
    return seq;
}

// Skip anything that contains letters outside A/C/G/U
unordered_map<string, size_t> count_codons(const string& rna) {
    unordered_map<string, size_t> cnt;
    const size_t n = rna.size();
    for (size_t i = 0; i + 2 < n; i += 3) {
        string codon = rna.substr(i, 3);
        if (CODON.find(codon) != CODON.end())
            ++cnt[codon];
    }
    return cnt;
}

template <class K, class V>
vector<pair<K,V>> top_n(const unordered_map<K,V>& m, size_t N) {
    vector<pair<K,V>> v(m.begin(), m.end());
    partial_sort(v.begin(), v.begin()+min(N, v.size()), v.end(),
                 [](auto& a, auto& b){ return a.second > b.second; });
    if (v.size() > N) v.resize(N);
    return v;
}

void print_table(const string& title,
                 const vector<pair<string,size_t>>& rows)
{
    cout << "\n" << title << "\n";
    cout << "--------------------------------------\n";
    cout << left << setw(8) << "Codon"
         << setw(8) << "Count"
         << setw(8) << "AA(1)"
         << setw(8) << "AA(3)" << "\n";
    for (auto& [codon, c] : rows) {
        char aa = CODON.at(codon);
        string aa3 = AA3.at(aa);
        cout << left << setw(8) << codon
             << setw(8) << c
             << setw(8) << aa
             << setw(8) << aa3 << "\n";
    }
}

vector<tuple<string,size_t,char>> top_codons(const unordered_map<string,size_t>& cnt, size_t N) {
    auto v = top_n(cnt, N);
    vector<tuple<string,size_t,char>> out;
    out.reserve(v.size());
    for (auto& [k, c] : v) out.emplace_back(k, c, CODON.at(k));
    return out;
}

vector<pair<char,size_t>> aa_counts_from_codons(const unordered_map<string,size_t>& cnt) {
    unordered_map<char,size_t> aaCnt;
    for (auto& [codon, c] : cnt) {
        char aa = CODON.at(codon);
        if (aa == '*') continue;
        aaCnt[aa] += c;
    }
    return top_n(aaCnt, 20);
}

int main() {
    const string fluPath   = "data/Influenza.fna";
    const string covidPath = "data/Covid.fna";

    try {
        auto fluSeq   = read_fasta_rna(fluPath);
        auto covSeq   = read_fasta_rna(covidPath);

        auto fluCodon = count_codons(fluSeq);
        auto covCodon = count_codons(covSeq);

        // a) top 10 influenza codons
        auto fluTop10 = top_n(fluCodon, 10);
        print_table("Top 10 Codons — Influenza A", fluTop10);

        // b) top 10 covid codons
        auto covTop10 = top_n(covCodon, 10);
        print_table("Top 10 Codons — SARS-CoV-2", covTop10);

        // c) compare
        auto fluTop1 = fluTop10.empty()? pair<string,size_t>{"",0} : fluTop10[0];
        auto covTop1 = covTop10.empty()? pair<string,size_t>{"",0} : covTop10[0];

        unordered_map<string,bool> inFlu;
        for (auto& p : fluTop10) inFlu[p.first] = true;

        cout << "\nComparison (most frequent + overlaps among top-10):\n";
        cout << "Influenza top codon: " << fluTop1.first
             << " (AA " << CODON.at(fluTop1.first) << ", count " << fluTop1.second << ")\n";
        cout << "SARS-CoV-2 top codon: " << covTop1.first
             << " (AA " << CODON.at(covTop1.first) << ", count " << covTop1.second << ")\n";

        cout << "Shared codons in both top-10 lists: ";
        bool first = true;
        for (auto& p : covTop10) {
            if (inFlu.count(p.first)) {
                if (!first) cout << ", ";
                cout << p.first;
                first = false;
            }
        }
        if (first) cout << "(none)";
        cout << "\n";

        // d) top 3 amino acids for each genome
        auto fluAA  = aa_counts_from_codons(fluCodon);
        auto covAA  = aa_counts_from_codons(covCodon);

        auto showTop3AA = [](const string& label,
                             const vector<pair<char,size_t>>& aaRank)
        {
            cout << "\nTop 3 amino acids — " << label << ":\n";
            for (size_t i=0; i<min<size_t>(3, aaRank.size()); ++i) {
                char aa = aaRank[i].first;
                size_t c = aaRank[i].second;
                cout << (i+1) << ". " << aa << " (" << AA3.at(aa) << ") — " << c << "\n";
            }
        };
        showTop3AA("Influenza A", fluAA);
        showTop3AA("SARS-CoV-2",  covAA);

        // e) AI prompts
        auto three = [](const vector<pair<char,size_t>>& v){
            vector<string> out;
            for (size_t i=0; i<min<size_t>(3, v.size()); ++i) out.push_back(AA3.at(v[i].first));
            return out;
        };
        auto flu3 = three(fluAA);
        auto cov3 = three(covAA);

        cout << "\nAI prompt (Influenza):\n";
        cout << "“Which foods are naturally low in " << flu3[0]
             << ", " << flu3[1] << ", and " << flu3[2]
             << "? Please cite reliable nutrition sources.”\n";

        cout << "\nAI prompt (SARS-CoV-2):\n";
        cout << "“Which foods are naturally low in " << cov3[0]
             << ", " << cov3[1] << ", and " << cov3[2]
             << "? Please cite reliable nutrition sources.”\n";

    } catch (const exception& e) {
        cerr << "Error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
