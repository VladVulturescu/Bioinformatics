#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

// Return complement of a base
char comp(char c) {
    switch (c) {
        case 'A': return 'T';
        case 'T': return 'A';
        case 'C': return 'G';
        case 'G': return 'C';
        default:  return 'N';
    }
}

// Reverse complement of a string
string reverse_complement(const string &s) {
    string rc = s;
    reverse(rc.begin(), rc.end());
    for (char &c : rc) c = comp(c);
    return rc;
}

string read_fasta(const string &filename) {
    ifstream in(filename);
    if (!in) {
        cerr << "Error: cannot open file " << filename << "\n";
        exit(1);
    }

    string line, genome;
    while (getline(in, line)) {
        if (line.empty()) continue;
        if (line[0] == '>') continue; // skip the header
        for (char &c : line) {
            char u = toupper(c);
            if (u == 'A' || u == 'C' || u == 'G' || u == 'T')
                genome.push_back(u);
        }
    }

    return genome;
}

struct RepeatInfo {
    int start_left;
    int end_left;
    int start_right;
    int end_right;
    int length;
};

int main(int argc, char** argv) {
    if (argc < 2) {
        cout << "Usage: ./Bioinfo_L8E3 <genome.fasta>\n";
        return 0;
    }

    string genome = read_fasta(argv[1]);
    cout << "Loaded genome of length: " << genome.size() << " bp\n\n";

    const vector<int> lengths = {5, 6};
    vector<RepeatInfo> results;

    //sliding window
    for (int len : lengths) {
        for (int i = 0; i < (int)genome.size() - len; i++) {

            string left = genome.substr(i, len);
            string left_rc = reverse_complement(left);

            for (int j = i + len; j < (int)genome.size() - len; j++) {

                string right = genome.substr(j, len);

                if (right == left_rc) {
                    RepeatInfo r;
                    r.start_left = i;
                    r.end_left = i + len - 1;
                    r.start_right = j;
                    r.end_right = j + len - 1;
                    r.length = len;
                    results.push_back(r);
                }
            }
        }
    }

    cout << "Detected inverted repeats (length 5–6 bp): " << results.size() << "\n\n";

    int id = 1;
    for (auto &r : results) {
        cout << "Repeat #" << id++ << ":\n";
        cout << "  Left : " << r.start_left << " - " << r.end_left << "\n";
        cout << "  Right: " << r.start_right << " - " << r.end_right << "\n";
        cout << "  Length: " << r.length << "\n\n";
    }

    return 0;
}
