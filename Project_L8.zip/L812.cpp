#include <iostream>
#include <string>
#include <random>
#include <vector>

using namespace std;


/// Task 1 - Make an artificial DNA sequence of 200-400 bases in length in which you simulate 3-4 transposable errorsÍ

struct InsertionInfo {
    int index0;
    int index1;
};

int main() {
    random_device rd;
    mt19937 gen(rd());

    uniform_int_distribution<> lengthDist(200, 400);
    int baseLength = lengthDist(gen);

    const char bases[] = {'A', 'C', 'G', 'T'};
    uniform_int_distribution<> baseDist(0, 3);

    string dna;
    dna.reserve(baseLength);
    for (int i = 0; i < baseLength; ++i) {
        dna.push_back(bases[baseDist(gen)]);
    }

    const string IRL  = "AAA";
    const string BODY = "TTTAAACCCGGGTTT";
    const string IRR  = "AAA";

    const string transposon = IRL + BODY + IRR;
    const int transLength = (int)transposon.size();

    uniform_int_distribution<> insertCountDist(3, 4);
    int insertionCount = insertCountDist(gen);

    vector<InsertionInfo> insertions;
    insertions.reserve(insertionCount);

    for (int i = 0; i < insertionCount; ++i) {
        uniform_int_distribution<> posDist(0, (int)dna.size());
        int pos = posDist(gen);

        dna.insert((string::size_type)pos, transposon);

        InsertionInfo info;
        info.index0 = pos;
        info.index1 = pos + 1;
        insertions.push_back(info);
    }

    cout << "Base DNA length: " << baseLength << " bp\n";
    cout << "Transposon sequence (" << transLength << " bp):\n";
    cout << transposon << "\n\n";

    cout << "Nr of transposon insertions: " << insertionCount << "\n";
    cout << "Insertion positions in final sequence:\n";
    cout << "(0-based index, 1-based index)\n";

    for (int i = 0; i < insertionCount; ++i) {
        cout << "  Insertion " << (i + 1) << ": "
             << insertions[i].index0 << " (0-based), "
             << insertions[i].index1 << " (1-based)\n";
    }

    cout << "\nFinal DNA length: " << dna.size() << " bp\n\n";

    cout << "Final DNA sequence:\n";
    cout << dna << "\n";

/// Task 2 - Implement a program that detects the positions of these transposable elements (start, end) within the created DNA sequence.
    cout << "\nDetecting transposable elements: \n\n";

    int detectedCount = 0;
    size_t searchPos = 0;

    while (true) {
        size_t found = dna.find(transposon, searchPos);
        if (found == string::npos) break;

        int start0 = (int)found;
        int end0   = (int)(found + transLength - 1);

        int start1 = start0 + 1;
        int end1   = end0 + 1;

        cout << "Detected transposon #" << (detectedCount + 1) << ":\n";
        cout << "  Start: " << start0 << " (0-based), " << start1 << " (1-based)\n";
        cout << "  End:   " << end0   << " (0-based), " << end1   << " (1-based)\n\n";

        detectedCount++;
        searchPos = found + 1;
    }

    if (detectedCount == 0) {
        cout << "No transposons detected.\n";
    } else {
        cout << "Detected transposons: " << detectedCount << "\n";
    }

    return 0;
}
