Vlad Alexandru Vulturescu

I solved the first two problems in a single file, that;s why the first .cpp file is named L812 instead of having a L81 and a L82 file
