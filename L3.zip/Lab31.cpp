#include <iostream>
#include <string>
#include <cmath>
#include <cctype>

using namespace std;

int main()
{
    string dna;
    cout << "Enter DNA: ";
    cin >> dna;
    
    for (char &c : dna) 
        c = toupper(c);
    
    int A=0, G=0, C=0, T=0;
    
    for (char b : dna) {
        if (b=='A') ++A; 
        else if (b=='T') ++T;
        else if (b=='G') ++G; 
        else if (b=='C') ++C;
    }
    
    int length = dna.size();
    int choice;
    
    cout << "Choose formula (1=simple 2=salt): ";
    cin >> choice;
    
    if (choice == 1) {
        double Tm =4.0*(G+C) + 2.0*(A+T);
        
        cout << "Tm (simple) = " << Tm << " C degrees\n";
    } else if (choice == 2) {
        double Na;
        
        cout << "Enter Na+ conentration: ";
        cin >> Na;
        
        double percentGC = 100.0*(G + C) / length;
        double Tm = 81.5 + 16.6*log10(Na) + 0.41*percentGC - 600.0/length;
        
        cout << "Tm (salt): " << Tm << " C degrees\n";
    } else {
        
        cout << "Invalid";
    }

    return 0;
}