import tkinter as tk
from tkinter import filedialog, messagebox
import matplotlib.pyplot as plt
import math
import numpy as np

def read_fasta(filepath):
    with open(filepath, 'r') as f:
        lines = f.readlines()
    return ''.join(line.strip() for line in lines if not line.startswith('>')).upper()

def simple_tm(seq):
    g = seq.count('G')
    c = seq.count('C')
    a = seq.count('A')
    t = seq.count('T')
    return 4*(g + c) + 2*(a + t)

def sliding_tm(seq, window=9, method='simple', smooth_window=5):
    tm_values = []
    for i in range(len(seq) - window + 1):
        window_seq = seq[i:i+window]
        if method == 'simple':
            tm = simple_tm(window_seq)
        tm_values.append(tm)
    tm_values_smoothed = np.convolve(tm_values, np.ones(smooth_window)/smooth_window, mode='same')
    return tm_values_smoothed

def analyze():
    if not filepath.get():
        messagebox.showwarning("Error", "Please select a FASTA file first.")
        return
    try:
        seq = read_fasta(filepath.get())
        method = formula_choice.get()
        window_size = int(window_entry.get())
        smooth_window = int(smooth_window_entry.get())
        tm_vals = sliding_tm(seq, window=window_size, method=method, smooth_window=smooth_window)
        x = list(range(len(tm_vals)))
        plt.figure(figsize=(10, 4))
        plt.plot(x, tm_vals, label="Smoothed Melting Temperature", color='black')
        plt.title("DNA Melting Temperature (Sliding Window with Smoothing)")
        plt.xlabel("Window Number")
        plt.ylabel("Temperature (°C)")
        plt.legend()
        plt.show()
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("DNA Melting Temperature Analyzer")

tk.Label(root, text="Select FASTA File:").grid(row=0, column=0, padx=10, pady=5)
filepath = tk.StringVar()
tk.Entry(root, textvariable=filepath, width=40).grid(row=0, column=1, padx=10, pady=5)
tk.Button(root, text="Browse", command=lambda: filepath.set(filedialog.askopenfilename())).grid(row=0, column=2, padx=10, pady=5)

tk.Label(root, text="Formula:").grid(row=1, column=0, padx=10, pady=5)
formula_choice = tk.StringVar(value='simple')
tk.OptionMenu(root, formula_choice, 'simple').grid(row=1, column=1)

tk.Label(root, text="Window Size:").grid(row=2, column=0, padx=10, pady=5)
window_entry = tk.Entry(root)
window_entry.insert(0, "9")
window_entry.grid(row=2, column=1, padx=10, pady=5)

tk.Label(root, text="Smoothing Window:").grid(row=3, column=0, padx=10, pady=5)
smooth_window_entry = tk.Entry(root)
smooth_window_entry.insert(0, "5")
smooth_window_entry.grid(row=3, column=1, padx=10, pady=5)

tk.Button(root, text="Run Analysis", command=analyze).grid(row=4, column=1, pady=10)

root.mainloop()
