Vlad Alexandru Vulturescu

Exercises 2 and 3 have alll been implemented as alterations to the peer-wise algorythm
