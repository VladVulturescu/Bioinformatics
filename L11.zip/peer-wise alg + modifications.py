from __future__ import annotations

import argparse
import os
from dataclasses import dataclass
from typing import List, Optional, Tuple


def read_fasta(path: str) -> List[Tuple[str, str]]:
    entries: List[Tuple[str, str]] = []
    header: Optional[str] = None
    seq_parts: List[str] = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if header is not None:
                    entries.append((header, "".join(seq_parts)))
                header = line[1:].strip() or "unnamed"
                seq_parts = []
            else:
                seq_parts.append(line)

    if header is not None:
        entries.append((header, "".join(seq_parts)))

    return entries


def clean_sequence(seq: str) -> str:

    return (
        seq.upper()
        .replace(" ", "")
        .replace("\t", "")
        .replace("\r", "")
        .replace("\n", "")
    )


def load_genomes(input_path: str) -> List[Tuple[str, str]]:

    if os.path.isdir(input_path):
        paths = []
        for fn in os.listdir(input_path):
            low = fn.lower()
            if low.endswith(".fa") or low.endswith(".fasta") or low.endswith(".fna"):
                paths.append(os.path.join(input_path, fn))
        paths.sort()

        genomes: List[Tuple[str, str]] = []
        for p in paths:
            records = read_fasta(p)
            if not records:
                continue
            h, s = records[0]
            name = os.path.basename(p) + " | " + h
            genomes.append((name, clean_sequence(s)))
        return genomes

    # file
    records = read_fasta(input_path)
    return [(h, clean_sequence(s)) for (h, s) in records]

@dataclass
class BlockAlignResult:
    aligned_a: str
    aligned_b: str
    consumed_b: int
    block_score: int


def _sub_score(a: str, b: str, match: int, mismatch: int) -> int:
    return match if a == b else mismatch


def align_block_fullA_to_prefixB(
    a: str,
    b: str,
    match: int,
    mismatch: int,
    gap: int,
    expected_b_consumption: Optional[int] = None,
) -> BlockAlignResult:

    n = len(a)
    m = len(b)

    if expected_b_consumption is None:
        expected_b_consumption = n

    score: List[List[int]] = [[0] * (m + 1) for _ in range(n + 1)]
    ptr: List[List[Optional[str]]] = [[None] * (m + 1) for _ in range(n + 1)]  # D/U/L

    for i in range(1, n + 1):
        score[i][0] = score[i - 1][0] + gap
        ptr[i][0] = "U"
    for j in range(1, m + 1):
        score[0][j] = score[0][j - 1] + gap
        ptr[0][j] = "L"

    for i in range(1, n + 1):
        ai = a[i - 1]
        for j in range(1, m + 1):
            d = score[i - 1][j - 1] + _sub_score(ai, b[j - 1], match, mismatch)
            u = score[i - 1][j] + gap
            l = score[i][j - 1] + gap

            best = d
            move = "D"
            if u > best:
                best = u
                move = "U"
            if l > best:
                best = l
                move = "L"

            score[i][j] = best
            ptr[i][j] = move

    best_j = 0
    best_val = score[n][0]

    def better_tie(j_new: int, j_old: int) -> bool:
        dn = abs(j_new - expected_b_consumption)
        do = abs(j_old - expected_b_consumption)
        if dn < do:
            return True
        if dn > do:
            return False
        return j_new > j_old  # more progress

    for j in range(1, m + 1):
        v = score[n][j]
        if v > best_val:
            best_val = v
            best_j = j
        elif v == best_val and better_tie(j, best_j):
            best_j = j

    # Traceback from (n, best_j)
    i, j = n, best_j
    out_a: List[str] = []
    out_b: List[str] = []

    while i > 0 or j > 0:
        mv = ptr[i][j]
        if mv == "D":
            out_a.append(a[i - 1])
            out_b.append(b[j - 1])
            i -= 1
            j -= 1
        elif mv == "U":
            out_a.append(a[i - 1])
            out_b.append("-")
            i -= 1
        else:  # "L"
            out_a.append("-")
            out_b.append(b[j - 1])
            j -= 1

    out_a.reverse()
    out_b.reverse()

    return BlockAlignResult(
        aligned_a="".join(out_a),
        aligned_b="".join(out_b),
        consumed_b=best_j,
        block_score=best_val,
    )

@dataclass
class LongAlignResult:
    aligned_a: str
    aligned_b: str
    matches: int
    length: int
    identity_percent: float
    score: int


def score_alignment(al_a: str, al_b: str, match: int, mismatch: int, gap: int) -> int:
    s = 0
    for x, y in zip(al_a, al_b):
        if x == "-" or y == "-":
            s += gap
        else:
            s += (match if x == y else mismatch)
    return s


def summarize_alignment(al_a: str, al_b: str, match: int, mismatch: int, gap: int) -> LongAlignResult:
    matches = 0
    for x, y in zip(al_a, al_b):
        if x == y and x != "-":
            matches += 1
    length = len(al_a)
    ident = (100.0 * matches / length) if length else 0.0
    sc = score_alignment(al_a, al_b, match, mismatch, gap)
    return LongAlignResult(aligned_a=al_a, aligned_b=al_b, matches=matches, length=length, identity_percent=ident, score=sc)


def align_genomes_blockwise(
    genome_a: str,
    genome_b: str,
    match: int = 1,
    mismatch: int = -1,
    gap: int = 0,
    block_size: int = 500,
    slack: int = 250,
) -> LongAlignResult:

    a = clean_sequence(genome_a)
    b = clean_sequence(genome_b)

    i = 0
    j = 0
    out_a_parts: List[str] = []
    out_b_parts: List[str] = []

    while i < len(a) and j < len(b):
        a_block = a[i : min(i + block_size, len(a))]
        b_window = b[j : min(j + block_size + slack, len(b))]

        if not a_block:
            break
        if not b_window:
            out_a_parts.append(a_block)
            out_b_parts.append("-" * len(a_block))
            i += len(a_block)
            continue

        blk = align_block_fullA_to_prefixB(
            a=a_block,
            b=b_window,
            match=match,
            mismatch=mismatch,
            gap=gap,
            expected_b_consumption=len(a_block),
        )

        if blk.consumed_b == 0 and len(b_window) > 0:
            blk = BlockAlignResult(
                aligned_a=blk.aligned_a,
                aligned_b=blk.aligned_b,
                consumed_b=min(len(b_window), max(1, len(a_block))),
                block_score=blk.block_score,
            )

        out_a_parts.append(blk.aligned_a)
        out_b_parts.append(blk.aligned_b)

        i += len(a_block)
        j += blk.consumed_b

    if i < len(a):
        tail_a = a[i:]
        out_a_parts.append(tail_a)
        out_b_parts.append("-" * len(tail_a))

    if j < len(b):
        tail_b = b[j:]
        out_a_parts.append("-" * len(tail_b))
        out_b_parts.append(tail_b)

    al_a = "".join(out_a_parts)
    al_b = "".join(out_b_parts)

    if len(al_a) != len(al_b):
        if len(al_a) < len(al_b):
            al_a += "-" * (len(al_b) - len(al_a))
        else:
            al_b += "-" * (len(al_a) - len(al_b))

    return summarize_alignment(al_a, al_b, match, mismatch, gap)


def alignment_three_lines(al_a: str, al_b: str) -> str:
    mid = []
    for x, y in zip(al_a, al_b):
        mid.append("|" if (x == y and x != "-") else " ")
    return al_a + "\n" + "".join(mid) + "\n" + al_b

def write_alignment_file(out_path: str, name_a: str, name_b: str, res: LongAlignResult) -> None:
    sim = similarity_percent_ungapped(res.aligned_a, res.aligned_b)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"Reference: {name_a}\n")
        f.write(f"Other:     {name_b}\n\n")

        f.write(f"Aligned length:          {res.length}\n")
        f.write(f"Matches:                {res.matches}\n")
        f.write(f"Identity (% over all):  {res.identity_percent:.2f}\n")
        f.write(f"Similarity (% ungapped): {sim:.2f}\n")
        f.write(f"Score:                  {res.score}\n\n")

        # "Plot" (proportional bar)
        f.write("Similarity bar (each char = 100 alignment columns):\n")
        f.write(alignment_similarity_bar(res.aligned_a, res.aligned_b, window=100))
        f.write("\n\n")

        f.write("Alignment:\n")
        f.write(alignment_three_lines(res.aligned_a, res.aligned_b))
        f.write("\n")


def similarity_percent_ungapped(al_a: str, al_b: str) -> float:
    assert len(al_a) == len(al_b)
    matches = 0
    valid = 0
    for x, y in zip(al_a, al_b):
        if x == "-" or y == "-":
            continue
        valid += 1
        if x == y:
            matches += 1
    return (100.0 * matches / valid) if valid else 0.0



def alignment_similarity_bar(
    al_a: str,
    al_b: str,
    window: int = 100
) -> str:

    assert len(al_a) == len(al_b)

    bar = []

    for i in range(0, len(al_a), window):
        a_chunk = al_a[i:i + window]
        b_chunk = al_b[i:i + window]

        matches = 0
        valid = 0

        for x, y in zip(a_chunk, b_chunk):
            if x == "-" or y == "-":
                continue
            valid += 1
            if x == y:
                matches += 1

        if valid == 0:
            bar.append("-")
        else:
            ratio = matches / valid
            if ratio >= 0.8:
                bar.append("=")
            elif ratio >= 0.5:
                bar.append("+")
            else:
                bar.append("-")

    return "[" + "".join(bar) + "]"

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Path to multi-FASTA file OR directory with fasta files")
    ap.add_argument("--out", default="results", help="Output directory (default: results)")
    ap.add_argument("--take", type=int, default=10, help="How many genomes to take (default: 10)")

    # Scoring
    ap.add_argument("--match", type=int, default=1)
    ap.add_argument("--mismatch", type=int, default=-1)
    ap.add_argument("--gap", type=int, default=0)

    # Block parameters
    ap.add_argument("--block", type=int, default=500, help="Block size from reference genome")
    ap.add_argument("--slack", type=int, default=250, help="Extra lookahead window in other genome")

    args = ap.parse_args()

    genomes = load_genomes(args.input)
    if len(genomes) < args.take:
        raise SystemExit(f"Need at least {args.take} genomes, but found {len(genomes)}")

    genomes = genomes[: args.take]
    ref_name, ref_seq = genomes[0]

    os.makedirs(args.out, exist_ok=True)
    summary_path = os.path.join(args.out, "summary.tsv")

    # We'll also print a nice console table at the end
    rows: List[Tuple[str, float, int]] = []  # (other_name, similarity%, score)

    with open(summary_path, "w", encoding="utf-8") as sf:
        # table required by the assignment (+ score for extra clarity)
        sf.write("ref\tother\tsimilarity_percent\tscore\taligned_len\tmatches\n")

        for idx in range(1, len(genomes)):
            name, seq = genomes[idx]
            print(f"[{idx}/{len(genomes)-1}] Aligning ref vs genome {idx+1} ...", flush=True)

            res = align_genomes_blockwise(
                ref_seq,
                seq,
                match=args.match,
                mismatch=args.mismatch,
                gap=args.gap,
                block_size=args.block,
                slack=args.slack,
            )

            sim = similarity_percent_ungapped(res.aligned_a, res.aligned_b)
            rows.append((name, sim, res.score))

            out_file = os.path.join(args.out, f"align_ref_vs_{idx+1}.txt")
            write_alignment_file(out_file, ref_name, name, res)

            sf.write(f"{ref_name}\t{name}\t{sim:.2f}\t{res.score}\t{res.length}\t{res.matches}\n")

    # Console table
    rows.sort(key=lambda t: t[1], reverse=True)

    print("\nSimilarity table (sorted by similarity %):")
    print(f"{'Genome':60}  {'Sim%':>7}  {'Score':>7}")
    print("-" * 80)
    for genome_name, simv, sc in rows:
        short = genome_name if len(genome_name) <= 60 else genome_name[:57] + "..."
        print(f"{short:60}  {simv:7.2f}  {sc:7d}")
    print()

    print(f"Done. Outputs written to: {args.out}")
    print(f"Summary: {summary_path}")


if __name__ == "__main__":
    main()
