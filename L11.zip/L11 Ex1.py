from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class AlignmentResult:
    s1: str
    s2: str
    match: int
    mismatch: int
    gap: int
    score_matrix: List[List[int]]
    pointer_matrix: List[List[Optional[str]]]  # "D", "U", "L"
    aligned_s1: str
    aligned_mid: str
    aligned_s2: str
    matches: int
    length: int
    similarity_percent: float
    final_score: int
    path: List[Tuple[int, int]]  # traceback coordinates (i, j) from end to start


def clean_sequence(seq: str) -> str:
    s = seq.upper().replace("\r", "").replace("\n", "").replace(" ", "")
    return s


def needleman_wunsch(
    s1_raw: str,
    s2_raw: str,
    match: int = 1,
    mismatch: int = -1,
    gap: int = 0,
) -> AlignmentResult:

    s1 = clean_sequence(s1_raw)
    s2 = clean_sequence(s2_raw)

    n = len(s1)
    m = len(s2)

    def sub(a: str, b: str) -> int:
        return match if a == b else mismatch

    # Score matrix
    score: List[List[int]] = [[0] * (m + 1) for _ in range(n + 1)]

    # Pointer matrix: "D" diag, "U" up, "L" left
    ptr: List[List[Optional[str]]] = [[None] * (m + 1) for _ in range(n + 1)]

    # Initialize first row/col
    for i in range(1, n + 1):
        score[i][0] = score[i - 1][0] + gap
        ptr[i][0] = "U"
    for j in range(1, m + 1):
        score[0][j] = score[0][j - 1] + gap
        ptr[0][j] = "L"

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            d = score[i - 1][j - 1] + sub(s1[i - 1], s2[j - 1])
            u = score[i - 1][j] + gap
            l = score[i][j - 1] + gap

            best = d
            move = "D"

            if u > best:
                best = u
                move = "U"
            if l > best:
                best = l
                move = "L"

            # Tie-break (diag > up > left)
            score[i][j] = best
            ptr[i][j] = move

    # Traceback
    i, j = n, m
    aligned1: List[str] = []
    aligned2: List[str] = []
    path: List[Tuple[int, int]] = []

    while i > 0 or j > 0:
        path.append((i, j))

        move = ptr[i][j]
        if move == "D":
            aligned1.append(s1[i - 1])
            aligned2.append(s2[j - 1])
            i -= 1
            j -= 1
        elif move == "U":
            aligned1.append(s1[i - 1])
            aligned2.append("-")
            i -= 1
        else:
            aligned1.append("-")
            aligned2.append(s2[j - 1])
            j -= 1

    path.append((0, 0))

    a1 = "".join(reversed(aligned1))
    a2 = "".join(reversed(aligned2))

    mid_chars = []
    matches = 0
    for c1, c2 in zip(a1, a2):
        if c1 == c2 and c1 != "-":
            mid_chars.append("|")
            matches += 1
        else:
            mid_chars.append(" ")
    mid = "".join(mid_chars)

    length = len(a1)
    similarity = (100.0 * matches / length) if length > 0 else 0.0
    final_score = score[n][m]

    return AlignmentResult(
        s1=s1,
        s2=s2,
        match=match,
        mismatch=mismatch,
        gap=gap,
        score_matrix=score,
        pointer_matrix=ptr,
        aligned_s1=a1,
        aligned_mid=mid,
        aligned_s2=a2,
        matches=matches,
        length=length,
        similarity_percent=similarity,
        final_score=final_score,
        path=path,
    )


def render_score_matrix(score: List[List[int]], s1: str, s2: str) -> str:
    n = len(s1)
    m = len(s2)
    max_val = max(max(row) for row in score) if score else 0
    min_val = min(min(row) for row in score) if score else 0
    cell_w = max(len(str(max_val)), len(str(min_val)), 2)

    def fmt(x: str) -> str:
        return x.rjust(cell_w)

    lines = []
    # Header row
    header = [" " * cell_w, fmt("-")]
    for ch in s2:
        header.append(fmt(ch))
    lines.append(" ".join(header))

    # Rows
    for i in range(n + 1):
        row_label = "-" if i == 0 else s1[i - 1]
        row = [fmt(row_label)]
        row.append(fmt(str(score[i][0])))
        for j in range(1, m + 1):
            row.append(fmt(str(score[i][j])))
        lines.append(" ".join(row))

    return "\n".join(lines)


def render_path_grid(n: int, m: int, path: List[Tuple[int, int]]) -> str:
    mark = [[False] * (m + 1) for _ in range(n + 1)]
    for (i, j) in path:
        if 0 <= i <= n and 0 <= j <= m:
            mark[i][j] = True

    lines = []
    for i in range(n + 1):
        line = []
        for j in range(m + 1):
            line.append("#" if mark[i][j] else ".")
        lines.append("".join(line))
    return "\n".join(lines)


def main() -> None:
    S1 = "ACCGTGAAGCCAATAC"
    S2 = "AGCGTGCAGCCAATAC"

    res = needleman_wunsch(S1, S2, match=1, mismatch=-1, gap=0)

    print("Show Alignment:\n")
    print(res.aligned_s1)
    print(res.aligned_mid)
    print(res.aligned_s2)
    print()
    print(f"Matches = {res.matches}")
    print(f"Length  = {res.length}")
    print(f"Similarity = {res.similarity_percent:.2f} %")
    print(f"Final score = {res.final_score}")

    if len(res.s1) <= 30 and len(res.s2) <= 30:
        print("\nScore Matrix:")
        print(render_score_matrix(res.score_matrix, res.s1, res.s2))
        print("\nTraceback Path Grid (# = path):")
        print(render_path_grid(len(res.s1), len(res.s2), res.path))


if __name__ == "__main__":
    main()
