import os
import matplotlib.pyplot as plt
import csv


def read_fasta(path):
    seq = ""
    with open(path) as f:
        for line in f:
            if not line.startswith(">"):
                seq += line.strip().upper()
    return seq


def extract_patterns(seq, kmin=3, kmax=6):
    freq = {}
    for k in range(kmin, kmax + 1):
        for i in range(len(seq) - k + 1):
            sub = seq[i:i + k]
            freq[sub] = freq.get(sub, 0) + 1
    return freq


DATA_DIR = "data"

all_patterns = {}

for filename in sorted(os.listdir(DATA_DIR)):
    if filename.endswith(".fna"):
        print("Reading:", filename)
        seq = read_fasta(os.path.join(DATA_DIR, filename))

        freq = extract_patterns(seq)

        for k, v in freq.items():
            all_patterns[k] = all_patterns.get(k, 0) + v

sorted_patterns = sorted(all_patterns.items(), key=lambda x: x[1], reverse=True)

top = sorted_patterns[:20]

with open("patterns.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["pattern", "frequency"])
    writer.writerows(top)

print("Wrote patterns.csv")

patterns = [x[0] for x in top]
counts = [x[1] for x in top]

plt.figure(figsize=(12, 6))
plt.bar(patterns, counts)
plt.title("Most Frequent 3–6 bp Patterns Across 10 Influenza Strains")
plt.xlabel("Pattern")
plt.ylabel("Frequency")
plt.tight_layout()
plt.savefig("patterns.png", dpi=300)

print("Saved patterns.png")
