#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;

string read_fasta(const string &filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        throw runtime_error("Cannot open FASTA file!");
    }

    string line;
    string seq = "";

    while (getline(file, line)) {
        if (line.empty()) continue;
        if (line[0] == '>') continue; // skip header
        for (char c : line) {
            if (c != '\n' && c != '\r' && c != ' ') {
                seq.push_back(toupper(c));
            }
        }
    }
    return seq;
}

// Detect repeats of size k, returns map substring -> list of positions
unordered_map<string, vector<int>> find_repeats(const string &seq, int k) {
    unordered_map<string, vector<int>> occurrences;

    for (int i = 0; i <= (int)seq.size() - k; i++) {
        string sub = seq.substr(i, k);
        occurrences[sub].push_back(i);
    }

    // Filter unique repeats (only those with >= 2 occurrences)
    unordered_map<string, vector<int>> repeats;
    for (auto &entry : occurrences) {
        if (entry.second.size() >= 2) {
            repeats[entry.first] = entry.second;
        }
    }

    return repeats;
}

int main() {
    try {
        string filename = "lab_sequence.fasta";
        string sequence = read_fasta(filename);

        cout << "Loaded sequence of length: " << sequence.size() << " bp\n";
        cout << "Repeats of length 3 to 6...\n\n";

        for (int k = 3; k <= 6; k++) {
            cout << "Repeats of length " << k << ": \n";

            auto rep = find_repeats(sequence, k);

            if (rep.empty()) {
                cout << "No repeats of length " << k << " found.\n\n";
                continue;
            }

            for (auto &entry : rep) {
                const string &sub = entry.first;
                const vector<int> &pos = entry.second;

                cout << sub
                     << " (" << pos.size() << " occurrences) - positions: ";

                for (int p : pos) cout << p << " ";
                cout << "\n";
            }

            cout << "\n";
        }

    } catch (const exception &ex) {
        cerr << "Error: " << ex.what() << "\n";
        return 1;
    }

    return 0;
}
