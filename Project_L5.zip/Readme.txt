Vlad Alexandru Vulturescu

I have tested the code with less samples and higher overlap in order to speed things up but the code works with the given paramenters as well... it will just take muhc much longer :)
