#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <random>
#include <algorithm>
#include <stdexcept>
#include <iomanip>

using namespace std;

string to_upper_dna(string s){
    for(char &c : s){ c = static_cast<char>(toupper(static_cast<unsigned char>(c))); if(c=='U') c='T'; }
    return s;
}
string read_fasta_sequence(const string &path){
    ifstream in(path);
    if(!in) throw runtime_error("Cannot open file: " + path);
    string line, seq;
    while(getline(in, line)){
        if(line.empty() || line[0] == '>') continue;   // skip header
        seq += line;
    }
    return to_upper_dna(seq);
}
void write_fasta(const string &path, const vector<string> &seqs, const string &prefix){
    ofstream out(path);
    if(!out) throw runtime_error("Cannot write " + path);
    for(size_t i=0;i<seqs.size();++i){
        out << ">" << prefix << "_" << (i+1) << "\n";
        const string &s = seqs[i];
        for(size_t j=0;j<s.size(); j+=80) out << s.substr(j, min<size_t>(80, s.size()-j)) << "\n";
    }
}
vector<string> sample_reads(const string &genome, int n_reads, int Lmin, int Lmax){
    random_device rd; mt19937 gen(rd());
    uniform_int_distribution<int> len_dist(Lmin, Lmax);
    vector<string> reads; reads.reserve(n_reads);
    for(int i=0;i<n_reads;++i){
        int L = len_dist(gen);
        if(L > (int)genome.size()) L = (int)genome.size();
        uniform_int_distribution<int> pos_dist(0, (int)genome.size() - L);
        int pos = pos_dist(gen);
        reads.push_back(genome.substr((size_t)pos,(size_t)L));
    }
    return reads;
}

int overlap(const string &a, const string &b, int k){
    int max_try = min<int>((int)a.size(), (int)b.size());
    for(int len=max_try; len>=k; --len){
        bool ok=true;
        for(int i=0;i<len;++i){
            if(a[(int)a.size()-len+i] != b[i]){ ok=false; break; }
        }
        if(ok) return len;
    }
    return 0;
}
vector<string> drop_contained(vector<string> reads){
    sort(reads.begin(), reads.end(), [](const string&x,const string&y){return x.size()>y.size();});
    vector<string> keep;
    for(const auto &r: reads){
        bool contained=false;
        for(const auto &k: keep){ if(k.find(r)!=string::npos){ contained=true; break; } }
        if(!contained) keep.push_back(r);
    }
    return keep;
}
string greedy_assemble(vector<string> reads, int k){
    if(reads.empty()) return "";
    reads = drop_contained(move(reads));
    while(reads.size()>1){
        int best=-1; size_t bi=0,bj=1;
        for(size_t i=0;i<reads.size();++i)
            for(size_t j=0;j<reads.size();++j){
                if(i==j) continue;
                int ol = overlap(reads[i], reads[j], k);
                if(ol>best){ best=ol; bi=i; bj=j; }
            }
        if(best<k){
            string contig = reads[0];
            for(size_t i=1;i<reads.size();++i) contig += string((size_t)k,'N') + reads[i];
            return contig;
        }
        string merged = reads[bi] + reads[bj].substr((size_t)best);
        vector<string> next; next.reserve(reads.size()-1);
        for(size_t t=0;t<reads.size();++t) if(t!=bi && t!=bj) next.push_back(reads[t]);
        next.push_back(move(merged));
        reads.swap(next);
    }
    return reads.front();
}

// longest exact common substring anywhere between reference and assembled
pair<int,double> longest_prefix_match(const string &reference, const string &assembled){
    // O(n*m) time, O(m) memory; fine for ~30k vs ~30k in Release build
    const size_t n = reference.size();
    const size_t m = assembled.size();
    int best = 0;

    // rolling 1D DP for Longest Common Substring
    vector<int> prev(m + 1, 0), curr(m + 1, 0);
    for (size_t i = 1; i <= n; ++i) {
        for (size_t j = m; j >= 1; --j) {
            if (reference[i - 1] == assembled[j - 1]) {
                curr[j] = prev[j - 1] + 1;
                if (curr[j] > best) best = curr[j];
            } else {
                curr[j] = 0;
            }
        }
        swap(prev, curr);
    }

    double pct = reference.empty() ? 0.0 : (100.0 * best / (double)reference.size());
    return {best, pct};
}



int main(){
    try{
        const string fasta_name = "Covid.fna";

        string genome = read_fasta_sequence(fasta_name);
        cout << "Genome length: " << genome.size() << " bases\n";

        const int NREADS=300, LMIN=100, LMAX=150, K=40;
        auto reads = sample_reads(genome, NREADS, LMIN, LMAX);
        cout << "Generated " << reads.size() << " reads.\n";
        write_fasta("reads.fasta", reads, "read");
        cout << "Saved to reads.fasta\n";

        string contig = greedy_assemble(reads, K);
        write_fasta("assembly.fasta", vector<string>{contig}, "contig");
        cout << "Assembly length: " << contig.size() << " (assembly.fasta)\n";

        ofstream rep("explanation.txt");
        if(rep){
            auto [best, pct] = longest_prefix_match(genome, contig);
            rep << "Reference length: " << genome.size() << " bp\n";
            rep << "Reads: " << NREADS << " (len " << LMIN << "-" << LMAX << ")\n";
            rep << "Min overlap (k): " << K << "\n";
            rep << "Assembly length: " << contig.size() << " bp\n";
            rep << "Longest exact match of reference prefix in assembly: "
                << best << " bp (" << fixed << setprecision(2) << pct << "%)\n\n";
            rep << "Main problem: The greedy 'largest overlap first' way of solving the problem is not globally optimal. "
                   "Repeats and/or low-complexity can cause overlaps resulting in unfaithful reconstructions or collapsed repeats. "
                   ". The uneven coverage leaves gaps, with errors hiding actual overlaps.\n";
        }
        cout << "Wrote explanation.txt\n";
    }catch(const exception &e){
        cerr << "Error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
