import math
from typing import Dict, List, Tuple

BASES = ["A", "C", "G", "T"]
NULL_P = 0.25  # null model


def validate_sequences(seqs: List[str]) -> int:
    if not seqs:
        raise ValueError("No sequences provided.")
    L = len(seqs[0])
    for s in seqs:
        if len(s) != L:
            raise ValueError("All motif sequences must have the same length.")
        for ch in s:
            if ch not in BASES:
                raise ValueError(f"Invalid base '{ch}' found. Only A/C/G/T allowed.")
    return L


def count_matrix(seqs: List[str]) -> Dict[str, List[int]]:
    L = validate_sequences(seqs)
    counts = {b: [0] * L for b in BASES}
    for s in seqs:
        for j, ch in enumerate(s):
            counts[ch][j] += 1
    return counts


def frequency_matrix(counts, n, pseudocount=1):
    L = len(next(iter(counts.values())))
    total = n + 4 * pseudocount
    freqs = {b: [0.0] * L for b in ["A", "C", "G", "T"]}
    for b in ["A", "C", "G", "T"]:
        for j in range(L):
            freqs[b][j] = (counts[b][j] + pseudocount) / total
    return freqs


def log_likelihood_matrix(freqs: Dict[str, List[float]], null_p: float = NULL_P) -> Dict[str, List[float]]:
    L = len(next(iter(freqs.values())))
    ll = {b: [float("-inf")] * L for b in BASES}
    for b in BASES:
        for j in range(L):
            p = freqs[b][j]
            if p > 0.0:
                ll[b][j] = math.log(p / null_p)
            else:
                ll[b][j] = float("-inf")
    return ll


def score_window(window: str, ll: Dict[str, List[float]]) -> float:
    # window length must match motif length
    total = 0.0
    for j, ch in enumerate(window):
        w = ll[ch][j]
        if w == float("-inf"):
            return float("-inf")
        total += w
    return total


def sliding_window_scores(S: str, motif_len: int, ll: Dict[str, List[float]]) -> List[Tuple[int, str, float]]:
    S = S.strip().upper()
    for ch in S:
        if ch not in BASES:
            raise ValueError(f"Invalid character '{ch}' in S. Only A/C/G/T allowed.")

    results = []
    for i in range(len(S) - motif_len + 1):
        w = S[i:i + motif_len]
        sc = score_window(w, ll)
        results.append((i, w, sc))
    return results


def pretty_print_matrix_int(title: str, mat: Dict[str, List[int]]) -> None:
    L = len(next(iter(mat.values())))
    print(f"\n{title}")
    print("     " + " ".join(f"{j+1:>6}" for j in range(L)))
    for b in BASES:
        print(f"{b:>3}  " + " ".join(f"{mat[b][j]:>6d}" for j in range(L)))


def pretty_print_matrix_float(title: str, mat: Dict[str, List[float]], digits: int = 3) -> None:
    L = len(next(iter(mat.values())))
    fmt = f"{{:>6.{digits}f}}"
    print(f"\n{title}")
    print("     " + " ".join(f"{j+1:>6}" for j in range(L)))
    for b in BASES:
        row = []
        for j in range(L):
            x = mat[b][j]
            if x == float("-inf"):
                row.append(f"{'-inf':>6}")
            else:
                row.append(fmt.format(x))
        print(f"{b:>3}  " + " ".join(row))


def main():

    motif_seqs = ["GAGGTAAAC","TCCGTAAGT","CAGGTTGGA","ACAGTCAGT","TAGGTCATT","TAGGTACTG","ATGGTAACT","CAGGTATAC","TGTGTGAGT",]

    S = "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA"

    counts = count_matrix(motif_seqs)
    pretty_print_matrix_int("Count matrix: ", counts)

    n = len(motif_seqs)
    freqs = frequency_matrix(counts, n)
    pretty_print_matrix_float("Relative frequency matrix: ", freqs, digits=3)

    ll = log_likelihood_matrix(freqs, NULL_P)
    pretty_print_matrix_float("Log-likelihood matrix ln: ", ll, digits=3)

    L = len(motif_seqs[0])
    scores = sliding_window_scores(S, L, ll)

    print(f"\nSliding window scores over S (window length {L}): ")
    print(" idx: window:     score:")
    best = None
    for i, w, sc in scores:
        sc_str = "-inf" if sc == float("-inf") else f"{sc:.6f}"
        print(f"{i:>4}  {w}   {sc_str}")
        if sc != float("-inf"):
            if best is None or sc > best[2]:
                best = (i, w, sc)

    if best is None:
        print("\nNo finite scores (every window had at least one -inf due to zero probabilities).")
        print("If your lab expects finite scores, you may need pseudocounts (ask and I’ll add them).")
    else:
        i, w, sc = best
        print(f"\nBest hit: start index {i} (0-based), window='{w}', score={sc:.6f}")
        print("Interpretation: a higher score suggests this window matches the exon–intron motif better than random.")


if __name__ == "__main__":
    main()
