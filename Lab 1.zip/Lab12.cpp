#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main() {
    string S = "ATTTCGCCGATA";
    string alphabet = "";

    for (char c : S) {
        if (alphabet.find(c) == string::npos)
            alphabet += c;
    }

    cout << "Alphabet: " << alphabet << endl;

    int n = S.size();
    cout << "Relative frequencies:\n";
    for (char symbol : alphabet) {
        int count = 0;
        for (char c : S) {
            if (c == symbol) count++;
        }
        double freq = (double)count / n * 100;
        cout << symbol << " = " << fixed << setprecision(2) << freq << "%" << endl;
    }

    return 0;
}
