import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

def count_fasta(path, dna_only=False, progress_cb=None):
    with open(path, 'rb') as f:
        header = f.readline()
        if not header:
            raise ValueError("Empty or unreadable file.")
        seq_start = f.tell()

        # Show explicit seek as requested by the assignment
        f.seek(0, os.SEEK_SET)
        f.seek(seq_start, os.SEEK_SET)

        CHUNK = 8 * 1024 * 1024  # 8 MB
        counts = [0]*256
        total_letters = 0
        size = os.path.getsize(path)

        while True:
            # update progress before reading (position of file pointer)
            pos = f.tell()
            if progress_cb and size:
                progress_cb(int(pos * 100 / size))

            buf = f.read(CHUNK)
            if not buf:
                break

            for b in buf:
                if b == 10 or b == 13:  # \n or \r
                    continue
                # a..z -> A..Z (ASCII)
                if 97 <= b <= 122:
                    b -= 32
                if 65 <= b <= 90:
                    if dna_only and b not in (65, 67, 71, 84):  # A,C,G,T
                        continue
                    counts[b] += 1
                    total_letters += 1

        if progress_cb:
            progress_cb(100)

    return header.decode(errors='replace').strip(), counts, total_letters

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("FASTA Letter Frequencies")
        self.geometry("650x450")

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=8)

        self.btn = ttk.Button(top, text="Open FASTA…", command=self.open_file)
        self.btn.pack(side="left")

        self.dna_only_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text="DNA-only (A/C/G/T)", variable=self.dna_only_var).pack(side="left", padx=12)

        self.progress = ttk.Progressbar(self, orient="horizontal", mode="determinate")
        self.progress.pack(fill="x", padx=10, pady=6)

        cols = ("Letter", "Count", "Percentage")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=12)
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, anchor="center", width=120 if c != "Letter" else 80)
        self.tree.pack(fill="both", expand=True, padx=10, pady=6)

        self.info = ttk.Label(self, text="Pick a FASTA file (≥100 MB recommended).")
        self.info.pack(pady=4)

    def set_progress(self, val):
        self.progress["value"] = val
        self.update_idletasks()

    def open_file(self):
        path = filedialog.askopenfilename(title="Choose FASTA file")
        if not path:
            return
        try:
            header, counts, total = count_fasta(
                path,
                dna_only=self.dna_only_var.get(),
                progress_cb=self.set_progress
            )
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        # (Optional) warn if file is small
        try:
            if os.path.getsize(path) < 100*1024*1024:
                messagebox.showinfo("Note", "File is smaller than 100 MB. Proceeded anyway.")
        except Exception:
            pass

        # Fill table
        for i in self.tree.get_children():
            self.tree.delete(i)

        if total == 0:
            messagebox.showwarning("Warning", "No letters found after header.")
            return

        for code in range(65, 91):  # A..Z
            cnt = counts[code]
            if cnt == 0:
                continue
            pct = 100.0 * cnt / total
            self.tree.insert("", "end", values=(chr(code), cnt, f"{pct:.2f}%"))

        self.info.config(text=f"Header: {header}\nTotal letters: {total}")

if __name__ == "__main__":
    App().mainloop()
