#include <iostream>
#include <string>

using namespace std;

int main() {
    string S = "ATTTCGCCGATA";
    string alphabet = "";

    for (char c : S) {
        if (alphabet.find(c) == string::npos) 
            alphabet += c;
    }

    cout << "Alphabet: " << alphabet << endl;
    return 0;
}