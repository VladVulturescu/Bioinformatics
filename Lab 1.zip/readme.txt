This archive contains the solutions to the 3 assignments from Lab 1.

Contents:
---------
- Lab11.cpp : Assignment 1
    Finds the alphabet of a given DNA sequence (unique symbols in the sequence).

- Lab12.cpp : Assignment 2
    Computes the relative frequencies of the symbols found in a given DNA sequence.
    Output is displayed as symbol = percentage.

- Lab13.py  : Assignment 3
    GUI application (Python, Tkinter) that:
      Lets the user choose a FASTA file (≥100 MB recommended).
      Skips the header line (using seek to go directly to the sequence).
      Streams the sequence in 8 MB chunks to handle very large files.
      Computes percentages of all letters, with an optional DNA-only view (A/C/G/T).
      Displays results in a table with a progress bar.

- Screenshots/ :
    Contains screenshots of each program running:
      Lab11 (console alphabet output)
      Lab12 (console relative frequency output)
      Lab13 (GUI window with table of percentages)
