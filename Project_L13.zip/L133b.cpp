#include <algorithm>
#include <fstream>
#include <iostream>
#include <optional>
#include <random>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

namespace {

struct Args {
    std::string modelPath = "text_transition.json";
    int words = 60;
    int unit = 10;
    std::string start;
    std::string outPath;
    std::optional<uint32_t> seed;
};

void usage(const char* p) {
    std::cerr
      << "Usage:\n"
      << "  " << p << " [--model text_transition.json] [--words 60] [--unit 10]\n"
      << "       [--start WORD|ID] [--seed 123] [--out generated.txt]\n";
}

bool parseArgs(int argc, char** argv, Args& a) {
    for (int i = 1; i < argc; ++i) {
        std::string s = argv[i];
        if (s == "--model" && i + 1 < argc) a.modelPath = argv[++i];
        else if (s == "--words" && i + 1 < argc) a.words = std::stoi(argv[++i]);
        else if (s == "--unit" && i + 1 < argc) a.unit = std::stoi(argv[++i]);
        else if (s == "--start" && i + 1 < argc) a.start = argv[++i];
        else if (s == "--out" && i + 1 < argc) a.outPath = argv[++i];
        else if (s == "--seed" && i + 1 < argc) a.seed = (uint32_t)std::stoul(argv[++i]);
        else return false;
    }
    return a.words > 0 && a.unit > 0;
}

std::string readFile(const std::string& path) {
    std::ifstream f(path);
    if (!f) throw std::runtime_error("Cannot open model file: " + path);
    return std::string((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
}

void skipWs(const std::string& s, size_t& i) {
    while (i < s.size() && std::isspace((unsigned char)s[i])) ++i;
}
void expect(const std::string& s, size_t& i, char c) {
    skipWs(s, i);
    if (i >= s.size() || s[i] != c) throw std::runtime_error(std::string("Expected '") + c + "'");
    ++i;
}
std::string parseJsonString(const std::string& s, size_t& i) {
    skipWs(s, i);
    expect(s, i, '"');
    std::string out;
    while (i < s.size()) {
        char c = s[i++];
        if (c == '"') break;
        if (c == '\\' && i < s.size()) {
            char e = s[i++];
            if (e == '"' || e == '\\' || e == '/') out.push_back(e);
            else if (e == 'n') out.push_back('\n');
            else if (e == 'r') out.push_back('\r');
            else if (e == 't') out.push_back('\t');
            else out.push_back(e);
        } else out.push_back(c);
    }
    return out;
}
double parseNumber(const std::string& s, size_t& i) {
    skipWs(s, i);
    size_t j = i;
    while (j < s.size() && (std::isdigit((unsigned char)s[j]) || s[j]=='-' || s[j]=='+' || s[j]=='.' || s[j]=='e' || s[j]=='E')) ++j;
    if (j == i) throw std::runtime_error("Expected number");
    double v = std::stod(s.substr(i, j - i));
    i = j;
    return v;
}
std::vector<double> parseNumberArrayAt(const std::string& s, size_t& i) {
    expect(s, i, '[');
    std::vector<double> row;
    skipWs(s, i);
    if (i < s.size() && s[i] == ']') { ++i; return row; }
    while (true) {
        row.push_back(parseNumber(s, i));
        skipWs(s, i);
        if (s[i] == ']') { ++i; break; }
        expect(s, i, ',');
    }
    return row;
}
std::vector<std::vector<double>> parseMatrixAt(const std::string& s, size_t& i) {
    expect(s, i, '[');
    std::vector<std::vector<double>> m;
    skipWs(s, i);
    if (i < s.size() && s[i] == ']') { ++i; return m; }
    while (true) {
        m.push_back(parseNumberArrayAt(s, i));
        skipWs(s, i);
        if (s[i] == ']') { ++i; break; }
        expect(s, i, ',');
    }
    return m;
}
size_t findValueStart(const std::string& s, const std::string& key) {
    std::string k = "\"" + key + "\"";
    size_t p = s.find(k);
    if (p == std::string::npos) throw std::runtime_error("Missing key: " + key);
    p = s.find(':', p);
    if (p == std::string::npos) throw std::runtime_error("Bad JSON near key: " + key);
    ++p;
    skipWs(s, p);
    return p;
}


std::vector<std::string> extractVocabTokens(const std::string& js) {
    size_t p = js.find("\"vocab\"");
    if (p == std::string::npos) throw std::runtime_error("Missing key: vocab");
    p = js.find('[', p);
    if (p == std::string::npos) throw std::runtime_error("Bad vocab array");
    ++p;

    std::vector<std::string> tokens;
    while (true) {
        size_t t = js.find("\"token\"", p);
        size_t endArr = js.find(']', p);
        if (endArr == std::string::npos) throw std::runtime_error("Bad vocab array end");

        if (t == std::string::npos || t > endArr) break;
        t = js.find(':', t);
        if (t == std::string::npos) throw std::runtime_error("Bad token field");
        ++t;
        size_t i = t;
        std::string tok = parseJsonString(js, i);
        tokens.push_back(tok);
        p = i;
    }
    return tokens;
}

std::vector<int> makeBag(const std::vector<double>& p, int unit) {
    int n = (int)p.size();
    std::vector<int> base(n, 0);
    std::vector<std::pair<double,int>> frac; frac.reserve(n);

    int sum = 0;
    for (int j = 0; j < n; ++j) {
        double x = p[j] * unit;
        int b = (int)std::floor(x + 1e-12);
        base[j] = b;
        sum += b;
        frac.push_back({x - b, j});
    }

    int rem = unit - sum;
    std::sort(frac.begin(), frac.end(), [](auto& a, auto& b){ return a.first > b.first; });
    for (int k = 0; k < rem; ++k) base[frac[k % n].second]++;

    std::vector<int> bag;
    bag.reserve(unit);
    for (int j = 0; j < n; ++j)
        for (int c = 0; c < base[j]; ++c) bag.push_back(j);
    return bag;
}

bool isAllDigits(const std::string& s) {
    return !s.empty() && std::all_of(s.begin(), s.end(), [](unsigned char c){ return std::isdigit(c); });
}

}

int main(int argc, char** argv) {
    Args args;
    if (!parseArgs(argc, argv, args)) { usage(argv[0]); return 1; }

    try {
        std::string js = readFile(args.modelPath);

        auto vocab = extractVocabTokens(js);

        size_t iProb = findValueStart(js, "probabilities");
        auto P = parseMatrixAt(js, iProb);

        int n = (int)vocab.size();
        if ((int)P.size() != n) throw std::runtime_error("vocab/probabilities size mismatch");
        for (int r = 0; r < n; ++r) if ((int)P[r].size() != n) throw std::runtime_error("Non-square probability matrix");

        std::unordered_map<std::string,int> wordToId;
        wordToId.reserve(vocab.size());
        for (int i = 0; i < n; ++i) wordToId[vocab[i]] = i;

        std::vector<std::vector<int>> bags(n);
        for (int r = 0; r < n; ++r) bags[r] = makeBag(P[r], args.unit);

        uint32_t seed = args.seed.value_or(std::random_device{}());
        std::mt19937 rng(seed);

        auto pickFromBag = [&](int row) -> int {
            if (bags[row].empty()) {
                std::uniform_int_distribution<int> uni(0, n - 1);
                return uni(rng);
            }
            std::uniform_int_distribution<int> uni(0, (int)bags[row].size() - 1);
            return bags[row][uni(rng)];
        };

        int cur = 0;
        if (!args.start.empty()) {
            if (isAllDigits(args.start)) {
                cur = std::stoi(args.start);
                if (cur < 0 || cur >= n) throw std::runtime_error("Bad --start id");
            } else {
                auto it = wordToId.find(args.start);
                if (it == wordToId.end()) throw std::runtime_error("Bad --start word (not in vocab)");
                cur = it->second;
            }
        } else {
            std::uniform_int_distribution<int> uni(0, n - 1);
            cur = uni(rng);
        }

        std::string out;
        out.reserve(args.words * 6);

        out += vocab[cur];
        for (int k = 1; k < args.words; ++k) {
            int nxt = pickFromBag(cur);
            out += ' ';
            out += vocab[nxt];
            cur = nxt;
        }
        out += '\n';

        if (!args.outPath.empty()) {
            std::ofstream f(args.outPath);
            if (!f) throw std::runtime_error("Cannot open output: " + args.outPath);
            f << out;
            std::cout << "Wrote: " << args.outPath << "\n";
        } else {
            std::cout << out;
        }

        return 0;

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
}