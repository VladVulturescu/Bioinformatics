#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <optional>
#include <string>
#include <vector>

namespace {

// ---------- Utilities ----------
constexpr double EPS = 1e-9;

struct Config {
    int steps = 5;
    bool rowVector = true;
    bool normalizeEachStep = true;
    bool strictStochasticCheck = false;
    std::optional<std::string> inputPath;
};

void printUsage(const char* prog) {
    std::cerr
        << "Usage:\n"
        << "  " << prog << " [--file INPUT] [--steps K] [--mode row|col] [--no-normalize] [--strict]\n\n"
        << "Input format (whitespace separated):\n"
        << "  n\n"
        << "  P (n x n numbers)\n"
        << "  v0 (n numbers)\n\n"
        << "Example:\n"
        << "  3\n"
        << "  0.9 0.1 0.0\n"
        << "  0.2 0.7 0.1\n"
        << "  0.0 0.3 0.7\n"
        << "  1 0 0\n\n"
        << "Notes:\n"
        << "  --mode row assumes rows of P sum to 1 (row-stochastic).\n"
        << "  --mode col assumes columns of P sum to 1 (col-stochastic).\n";
}

bool approxEqual(double a, double b, double eps = EPS) {
    return std::fabs(a - b) <= eps;
}

double sumVec(const std::vector<double>& v) {
    return std::accumulate(v.begin(), v.end(), 0.0);
}

void normalize(std::vector<double>& v) {
    double s = sumVec(v);
    if (std::fabs(s) < EPS) return;
    for (double& x : v) x /= s;
}

int argmaxIndex(const std::vector<double>& v) {
    return static_cast<int>(std::distance(v.begin(), std::max_element(v.begin(), v.end())));
}

void printVector(int step, const std::vector<double>& v) {
    std::cout << "Step " << step << ": [";
    std::cout << std::fixed << std::setprecision(6);
    for (size_t i = 0; i < v.size(); ++i) {
        std::cout << v[i];
        if (i + 1 != v.size()) std::cout << ", ";
    }
    std::cout << "]";
    int idx = argmaxIndex(v);
    std::cout << "  (most likely state = " << idx << ", p=" << v[idx] << ")";
    std::cout << "\n";
}

using Matrix = std::vector<std::vector<double>>;

bool checkRowStochastic(const Matrix& P) {
    for (const auto& row : P) {
        double s = std::accumulate(row.begin(), row.end(), 0.0);
        if (!approxEqual(s, 1.0, 1e-6)) return false;
        for (double x : row) if (x < -1e-12) return false;
    }
    return true;
}

bool checkColStochastic(const Matrix& P) {
    const size_t n = P.size();
    for (size_t j = 0; j < n; ++j) {
        double s = 0.0;
        for (size_t i = 0; i < n; ++i) {
            if (P[i][j] < -1e-12) return false;
            s += P[i][j];
        }
        if (!approxEqual(s, 1.0, 1e-6)) return false;
    }
    return true;
}

std::vector<double> stepRowVector(const Matrix& P, const std::vector<double>& curr) {
    const size_t n = P.size();
    std::vector<double> next(n, 0.0);
    for (size_t j = 0; j < n; ++j) {
        double acc = 0.0;
        for (size_t i = 0; i < n; ++i) {
            acc += curr[i] * P[i][j];
        }
        next[j] = acc;
    }
    return next;
}

std::vector<double> stepColVector(const Matrix& P, const std::vector<double>& curr) {
    const size_t n = P.size();
    std::vector<double> next(n, 0.0);
    for (size_t i = 0; i < n; ++i) {
        double acc = 0.0;
        for (size_t j = 0; j < n; ++j) {
            acc += P[i][j] * curr[j];
        }
        next[i] = acc;
    }
    return next;
}

bool parseArgs(int argc, char** argv, Config& cfg) {
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];

        if (a == "--help" || a == "-h") {
            return false;
        } else if (a == "--file") {
            if (i + 1 >= argc) return false;
            cfg.inputPath = std::string(argv[++i]);
        } else if (a == "--steps") {
            if (i + 1 >= argc) return false;
            cfg.steps = std::stoi(argv[++i]);
            if (cfg.steps < 0) return false;
        } else if (a == "--mode") {
            if (i + 1 >= argc) return false;
            std::string m = argv[++i];
            if (m == "row") cfg.rowVector = true;
            else if (m == "col") cfg.rowVector = false;
            else return false;
        } else if (a == "--no-normalize") {
            cfg.normalizeEachStep = false;
        } else if (a == "--strict") {
            cfg.strictStochasticCheck = true;
        } else {
            return false;
        }
    }
    return true;
}

bool readInput(std::istream& in, Matrix& P, std::vector<double>& v0) {
    int n = 0;
    if (!(in >> n) || n <= 0) return false;

    P.assign(n, std::vector<double>(n, 0.0));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            if (!(in >> P[i][j])) return false;
        }
    }

    v0.assign(n, 0.0);
    for (int i = 0; i < n; ++i) {
        if (!(in >> v0[i])) return false;
    }

    return true;
}

}

int main(int argc, char** argv) {
    Config cfg{};
    if (!parseArgs(argc, argv, cfg)) {
        printUsage(argv[0]);
        return 1;
    }

    Matrix P;
    std::vector<double> v;

    if (cfg.inputPath) {
        std::ifstream fin(*cfg.inputPath);
        if (!fin) {
            std::cerr << "Cannot open file: " << *cfg.inputPath << "\n";
            return 1;
        }
        if (!readInput(fin, P, v)) {
            std::cerr << "Invalid input format in file.\n";
            return 1;
        }
    } else {
        std::cout << "Paste input (n, then n*n matrix values, then n vector values):\n";
        if (!readInput(std::cin, P, v)) {
            std::cerr << "Invalid input format.\n";
            return 1;
        }
    }

    const size_t n = P.size();
    if (v.size() != n) {
        std::cerr << "VEctor size does not match matrix dimension.\n";
        return 1;
    }

    // Basic distribution cleanup (common in Markov chains)
    if (cfg.normalizeEachStep) normalize(v);

    // Optional strict stochastic validation
    if (cfg.strictStochasticCheck) {
        bool ok = cfg.rowVector ? checkRowStochastic(P) : checkColStochastic(P);
        if (!ok) {
            std::cerr << "matrix is not stochastic for selected mode (row/col sums not ~1 or negatives).\n";
            return 1;
        }
    }

    std::cout << "\nMode: " << (cfg.rowVector ? "row (v_next = v * P)" : "col (v_next = P * v)") << "\n";
    std::cout << "Steps: " << cfg.steps << "\n\n";

    printVector(0, v);

    for (int step = 1; step <= cfg.steps; ++step) {
        v = cfg.rowVector ? stepRowVector(P, v) : stepColVector(P, v);
        if (cfg.normalizeEachStep) normalize(v);
        printVector(step, v);
    }

    return 0;
}
