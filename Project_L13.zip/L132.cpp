#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

namespace {

struct Args {
    std::string inPath;
    std::string outPath = "dna_transition.json";
};

bool parseArgs(int argc, char** argv, Args& a) {
    for (int i = 1; i < argc; ++i) {
        std::string s = argv[i];
        if (s == "--in") {
            if (i + 1 >= argc) return false;
            a.inPath = argv[++i];
        } else if (s == "--out") {
            if (i + 1 >= argc) return false;
            a.outPath = argv[++i];
        } else if (s == "--help" || s == "-h") {
            return false;
        } else {
            return false;
        }
    }
    return true;
}

void usage(const char* prog) {
    std::cerr
        << "Usage:\n"
        << "  " << prog << " [--in dna.txt] [--out dna_transition.json]\n\n"
        << "Input: DNA sequence (letters A,C,G,T), whitespace ignored.\n";
}

std::string readAllSequence(std::istream& in) {
    std::string seq;
    char ch;
    while (in.get(ch)) {
        if (std::isspace(static_cast<unsigned char>(ch))) continue;
        seq.push_back(static_cast<char>(std::toupper(static_cast<unsigned char>(ch))));
    }
    return seq;
}

std::string jsonEscape(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (char c : s) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"':  out += "\\\""; break;
            case '\n': out += "\\n";  break;
            case '\r': out += "\\r";  break;
            case '\t': out += "\\t";  break;
            default:   out += c;      break;
        }
    }
    return out;
}

}

int main(int argc, char** argv) {
    Args args;
    if (!parseArgs(argc, argv, args)) {
        usage(argv[0]);
        return 1;
    }

    const std::vector<char> alphabet = {'A', 'C', 'G', 'T'};
    std::unordered_map<char, int> idx;
    for (int i = 0; i < (int)alphabet.size(); ++i) idx[alphabet[i]] = i;

    std::string seq;
    if (!args.inPath.empty()) {
        std::ifstream fin(args.inPath);
        if (!fin) {
            std::cerr << "Cannot open input file: " << args.inPath << "\n";
            return 1;
        }
        seq = readAllSequence(fin);
    } else {
        std::cout << "Paste DNA sequence now (A,C,G,T), then Ctrl+D:\n";
        seq = readAllSequence(std::cin);
    }

    if (seq.size() < 2) {
        std::cerr << "Sequence too short (need at least 2 letters).\n";
        return 1;
    }

    // Validate symbols
    for (char c : seq) {
        if (!idx.count(c)) {
            std::cerr << "Invalid DNA symbol '" << c << "'. Allowed: A C G T\n";
            return 1;
        }
    }

    const int n = (int)alphabet.size();
    std::vector<std::vector<long long>> counts(n, std::vector<long long>(n, 0));
    std::vector<std::vector<double>> probs(n, std::vector<double>(n, 0.0));

    // Count transitions: seq[i] -> seq[i+1]
    for (size_t i = 0; i + 1 < seq.size(); ++i) {
        int a = idx[seq[i]];
        int b = idx[seq[i + 1]];
        counts[a][b]++;
    }

    // Row-normalize to probabilities
    for (int i = 0; i < n; ++i) {
        long long rowSum = 0;
        for (int j = 0; j < n; ++j) rowSum += counts[i][j];
        if (rowSum == 0) continue;
        for (int j = 0; j < n; ++j) probs[i][j] = (double)counts[i][j] / (double)rowSum;
    }

    // Write JSON
    std::ofstream out(args.outPath);
    if (!out) {
        std::cerr << "Cannot open output file: " << args.outPath << "\n";
        return 1;
    }

    out << "{\n";
    out << "  \"type\": \"dna_transition_matrix\",\n";
    out << "  \"order\": 0,\n";
    out << "  \"sequence\": \"" << jsonEscape(seq) << "\",\n";
    out << "  \"states\": [";
    for (int i = 0; i < n; ++i) {
        out << "\"" << alphabet[i] << "\"";
        if (i + 1 < n) out << ", ";
    }
    out << "],\n";

    out << "  \"counts\": [\n";
    for (int i = 0; i < n; ++i) {
        out << "    [";
        for (int j = 0; j < n; ++j) {
            out << counts[i][j];
            if (j + 1 < n) out << ", ";
        }
        out << "]";
        if (i + 1 < n) out << ",";
        out << "\n";
    }
    out << "  ],\n";

    out << "  \"probabilities\": [\n";
    out << std::fixed << std::setprecision(6);
    for (int i = 0; i < n; ++i) {
        out << "    [";
        for (int j = 0; j < n; ++j) {
            out << probs[i][j];
            if (j + 1 < n) out << ", ";
        }
        out << "]";
        if (i + 1 < n) out << ",";
        out << "\n";
    }
    out << "  ]\n";
    out << "}\n";

    std::cout << "Wrote: " << args.outPath << "\n";
    return 0;
}
