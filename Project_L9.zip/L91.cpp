#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

#include <pybind11/embed.h>
namespace py = pybind11;

using namespace std;

struct Enzyme {
    string name;
    string site;
    int cutOffset;
};

static string trim(const string& s) {
    size_t a = 0, b = s.size();
    while (a < b && isspace((unsigned char)s[a])) a++;
    while (b > a && isspace((unsigned char)s[b - 1])) b--;
    return s.substr(a, b - a);
}

static string loadSequence(const string& path) {
    ifstream in(path);
    if (!in) throw runtime_error("Cannot open file: " + path);

    string line;
    string seq;

    while (getline(in, line)) {
        line = trim(line);
        if (line.empty()) continue;
        if (line[0] == '>') continue; // FASTA header

        for (char c : line) {
            char u = toupper((unsigned char)c);
            if (isalpha(u)) seq.push_back(u);
        }
    }

    if (seq.empty()) throw runtime_error("No sequence found.");
    return seq;
}

static vector<int> findCuts(const string& seq, const Enzyme& enz) {
    vector<int> cuts;
    int N = seq.size();
    int M = enz.site.size();

    for (int i = 0; i + M <= N; i++) {
        if (seq.compare(i, M, enz.site) == 0) {
            int cut = i + enz.cutOffset;
            if (cut > 0 && cut < N)
                cuts.push_back(cut);
        }
    }

    sort(cuts.begin(), cuts.end());
    cuts.erase(unique(cuts.begin(), cuts.end()), cuts.end());
    return cuts;
}

static vector<int> digestLinear(int N, const vector<int>& cuts) {
    vector<int> frags;
    int prev = 0;
    for (int c : cuts) {
        frags.push_back(c - prev);
        prev = c;
    }
    frags.push_back(N - prev);
    return frags;
}

int main(int argc, char** argv) {
    if (argc < 2) {
        cout << "Usage: ./restriction_gel sequence.fasta\n";
        return 1;
    }

    string path = argv[1];
    string seq = loadSequence(path);
    int N = seq.size();

    vector<Enzyme> enzymes = {
        {"EcoRI",   "GAATTC", 1},
        {"BamHI",   "GGATCC", 1},
        {"HindIII", "AAGCTT", 1},
        {"TaqI",    "TCGA",   1},
        {"HaeIII",  "GGCC",   2}
    };

    vector<pair<string, vector<int>>> results;

    cout << "Sequence length = " << N << " bp\n\n";

    for (auto& e : enzymes) {
        auto cuts = findCuts(seq, e);
        auto frags = digestLinear(N, cuts);

        results.push_back({e.name, frags});

        cout << e.name << " ===\n";
        cout << "Recognition: " << e.site << "\n";
        cout << "Cuts: " << cuts.size() << "\n";

        if (cuts.empty()) {
            cout << "Cut positions: none\n";
        } else {
            cout << "Cut positions: ";
            for (int c : cuts) cout << c << " ";
            cout << "\n";
        }

        cout << "Fragments (bp): ";
        for (int f : frags) cout << f << " ";
        cout << "\n\n";
    }

    {
        py::scoped_interpreter guard{};

        const char* gel_py = R"(
import matplotlib.pyplot as plt
import numpy as np

def draw_gel(lanes, outfile="gel.png"):
    plt.figure(figsize=(6,8), dpi=200)
    ax = plt.gca()
    ax.set_facecolor("black")
    ax.invert_yaxis()

    spacing = 2
    max_size = max(max(v) for v in lanes.values())
    min_size = min(min(v) for v in lanes.values())

    def ypos(size):
        return np.log10(max_size) - np.log10(size)

    for lane_index, (name, frags) in enumerate(lanes.items()):
        x = lane_index * spacing
        for f in frags:
            y = ypos(f)
            ax.plot([x-0.4, x+0.4], [y, y], color='white', linewidth=5)

    ax.set_xticks([i*spacing for i in range(len(lanes))])
    ax.set_xticklabels(list(lanes.keys()), rotation=45, color='white')

    ax.tick_params(axis='x', colors='white')
    ax.tick_params(axis='y', colors='white')
    for spine in ax.spines.values():
        spine.set_color('white')

    ax.set_yticks([])
    plt.tight_layout()
    plt.savefig(outfile, facecolor='black', dpi=250)
    plt.close()
)";

        py::exec(gel_py);

        py::dict laneDict;
        for (auto& [name, frags] : results) {
            py::list pyfrags;
            for (int f : frags) pyfrags.append(f);
            laneDict[name.c_str()] = pyfrags;
        }

        py::module gelmod = py::module::import("__main__");
        gelmod.attr("draw_gel")(laneDict, "gel.png");
    }

    cout << "Gel image saved as gel.png\n";
    return 0;
}
